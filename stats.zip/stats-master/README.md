Контейнеры собираютсяп ри пуше коммитов или **вручную**. все остальное собирается из ямлов в кубе.
Продакшен
https://stat.smslab.ru

smsadmin

Gfhjkmrf

Инициализация приложения
```
smsreport migrate
smsreport createsuperuser
```
Команды приложения
```
smsreport buildstats
smsreport createpartition <numdays>
```
Команды крон
```
0 23 * * * /usr/local/bin/smsreport createpartition 2 >> /var/log/cron.log 2>&1
*/20 06-23 * * * /usr/local/bin/smsreport buildstats >> /var/log/cron.log 2>&1
0 0 * * * /usr/local/bin/smsreport buildstatsprevday 4 >> /var/log/cron.log 2>&1
0 1 1 * * /usr/local/bin/smsreport createarchiveprevmonth --number_of_group 1000000 --save_path /archive >> /var/log/cron.log 2>&1
*/10 * * * * /usr/local/bin/smsreport sendwarningsms dit >> /var/log/cron.log 2>&1
*/5 * * * * /usr/local/bin/smsreport tocountsmsmailing 4 >> /var/log/cron.log 2>&1
```
Конфиг приложения ~.config/smsreport/settings.py

Создать бд "sms", изменить настройки подключения DATABASES в settings.py

Установка проекта для developers (зависимости postgres, redis, memcached см. settings)
```
pip install -e .[develop]
celery -A smsreport worker -l info
smsreport runserver
```
