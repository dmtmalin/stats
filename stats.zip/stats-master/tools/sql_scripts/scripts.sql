-- Ручные выборки из БД

/*
Cреднее количество PDU на одно смс
*/
select
sum(pdu) / sum(sms)
FROM
(
SELECT
  count(id) / pdu_count as sms
  ,count(pdu_count) as pdu
  ,pdu_count
FROM sms_sms
WHERE submit_time >= '2017-03-11 00:00:00' and submit_time < '2017-03-14 00:00:59.999'
AND pdu_count IN (3)
GROUP BY pdu_count
) as a

/*
Среднее количество записей в час
*/
SELECT
	COUNT(id),
    EXTRACT(hour FROM create_time) as h,
    date_trunc('day', create_time) as d
FROM sms_sms
WHERE create_time >= '2017-09-01 00:00:00' and create_time < '2017-10-01 00:00:00'
GROUP BY d, h order by d, h;
