const path = require('path');
var webpack = require('webpack');
var HtmlWebpackPlugin = require('html-webpack-plugin');
const json = require('json-loader');
const UglifyJSPlugin = require('uglifyjs-webpack-plugin');
const ExtractTextPlugin = require("extract-text-webpack-plugin");

module.exports = {
    context: path.resolve(__dirname, 'front-fish'),
    entry: path.resolve(__dirname, "./src/main.js"),
    output: {
        path: path.resolve(__dirname, './dist/'),
        publicPath: "/static/",
        filename: "bundle.min.js"
    },
    module: {
        loaders: [
            {
                test: /\.js$/,
                loader: "babel-loader",
                exclude: [/node_modules/, /public/]
            },
            {
                test: /\.css$/,
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: "css-loader"
                })
            },
            {
                test: /\.scss$/,
                use: ExtractTextPlugin.extract({
                    fallback: 'style-loader',
                    use: ['css-loader', 'sass-loader']
                })
            },
            {
                test: /\.(woff2?|ttf|eot|svg)$/,
                loader: 'url-loader?limit=10000&name=[name].[ext]'
            },
            {
                test: /bootstrap\/dist\/js\/umd\//,
                loader: 'imports?jQuery=jquery'
            },
            {
                include: /\.json$/,
                loaders: ['json-loader']
            }
        ]
    },

    plugins: [
        new HtmlWebpackPlugin({
            filename: 'report.html',
            title: 'Статистика',
            template: path.resolve(__dirname, './src/report.html')
        }),
        new HtmlWebpackPlugin({
            filename: 'sms.html',
            title: 'SMS',
            template: path.resolve(__dirname, './src/sms.html')
        }),
        new HtmlWebpackPlugin({
            filename: 'create.html',
            title: 'Рассылки',
            template: path.resolve(__dirname, './src/create.html')
        }),
        new HtmlWebpackPlugin({
            filename: 'mailing.html',
            title: 'Рассылки',
            template: path.resolve(__dirname, './src/mailing.html')
        }),
        new HtmlWebpackPlugin({
            filename: 'queue.html',
            title: 'Переотправленные сообщения',
            template: path.resolve(__dirname, './src/queue.html')
        }),
        new HtmlWebpackPlugin({
            filename: 'resend.html',
            title: 'Переотправленные сообщения',
            template: path.resolve(__dirname, './src/resend.html')
        }),
        new HtmlWebpackPlugin({
            filename: 'login.html',
            title: 'Домашняя страница',
            template: path.resolve(__dirname, './src/login.html')
        }),
        new webpack.ProvidePlugin({
            jQuery: 'jquery',
            $: 'jquery',
            jquery: 'jquery'
        }),
        new webpack.ProvidePlugin({
            moment: "moment"
        }),
        new webpack.ProvidePlugin({
            jsonprocessor: "jsonprocessor"
        }),
        new webpack.ContextReplacementPlugin(/\.\/locale$/, 'empty-module', false, /js$/),
        new webpack.optimize.UglifyJsPlugin({
            include: /\.min\.js$/,
            minimize: true,
            sourceMap: true
        }),
        new ExtractTextPlugin('bundle.css'),
    ]
}
