$(function () {
    $(".mailing-text").shorten({
        "showChars": 25,
	    "moreText": ">>>",
        "lessText": "<<<"
    });
    $(".destinations").shorten({
        "showChars": 11,
	    "moreText": ">>>",
        "lessText": "<<<"
    });
});
