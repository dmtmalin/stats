
$(function () {
    $('#start_time').datetimepicker({
        format: "YYYY-MM-DD 00:00:00",
        defaultDate: new Date(),
    });
    $('#end_time').datetimepicker({
        format: "YYYY-MM-DD 23:59:59",
        defaultDate: new Date(),
    });
});

$('.js-btn-today').on('click', function() {
    $('#start_time').data('DateTimePicker').date(
        moment().startOf('day')
    );
    $('#end_time').data('DateTimePicker').date(
        moment().endOf('day')
    );
});

$('.js-btn-month').on('click', function() {
    $('#start_time').data('DateTimePicker').date(
        moment().startOf('month')
    );
    $('#end_time').data('DateTimePicker').date(
        moment().endOf('month')
    );
});