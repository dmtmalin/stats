
$(function () {
    new AjaxForm($('.ajax-send-sms'), {
        complete: function (data) {
            var response = $.parseJSON(data.responseText);
            $.each(response.sms_sends, function (key, value) {
                $('#row_' + value).remove();
            });
        }
    });
});

$(function () {
    $('.ajax-mass-send-sms').confirm({
        text: "Выполнить массовую переотправку?",
        title: "Необходимо подтверждение",
        confirm: function(button) {
            $('.please-wait').modal('show');

            $.ajax({
                method: 'post',
                url: button.attr('data-url'),
                success: function (data){

                    var report = [];

                    report.push(data.message);

                    // data filter
                    /*$.each(data.filter, function (key, value) {
                        report.push(key + ': ' + value);
                    });*/

                    //remove table and paginator
                    $('.sms-table').find('tr:gt(0)').remove();
                    $('.pagination').remove();

                    //hide please wait
                    $('.please-wait').modal('hide');

                    alert(report.join('\n'));
                }
            });
        },
        confirmButton: "Да",
        cancelButton: "Нет"
    });
});

$(function () {
    $('.check-all').on('click', function () {
        $('.table > tbody > tr > td > input').each(function () {
            var input = $(this);
            (this.checked ? input.prop('checked', false) : input.prop('checked', true));
        });
    });
});
