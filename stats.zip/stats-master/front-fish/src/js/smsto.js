//open header-menu for mobile
$(function() {
    $(".header-menu-btn").click(function(event) {
        $('.nav.navbar-nav').addClass("active");

        event.stopPropagation();
    });

    $(".navbar-close").click(function() {
        $('.nav.navbar-nav').removeClass("active");
    });
});
//open mobile version nav
$(document).on('click', function (e) {
    var container = $('.nav.navbar-nav');

    if ($(e.target).closest(container).length === 0) {
        $('.nav.navbar-nav').removeClass("active");
    }
});
