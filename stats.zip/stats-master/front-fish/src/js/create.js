$(function () {
    $('#eta').datetimepicker({
        format: "YYYY-MM-DD  HH:mm:ss"
    });
});

function ClearEta() {

}
$('.js-clear-btn').on('click', function() {
    $('#eta').data('DateTimePicker').clear();
});