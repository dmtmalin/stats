$(function () {
    var navbar = $(".navbar-fixed-top");
    navbar.autoHidingNavbar({
        showOnUpscroll: false,
        showOnBottom: false,
        hideOffset: 10
    });
    //navbar.autoHidingNavbar('hide');
});
