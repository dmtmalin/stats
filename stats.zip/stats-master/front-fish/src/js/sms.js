
$(function () {
    $(".sms-info").shorten({
        "showChars": 25,
	    "moreText": ">>>",
        "lessText": "<<<"
    });
});
