#!/usr/bin/env bash
# Запускаем миграции к БД, параметры подключения к БД берутся из окружения
#echo "MIGRATE DATABASE"
#/usr/local/bin/smsreport migrate
# Создаем партиции БД
echo "CREATE PARTITION FOR 7 DAYS"
#/usr/local/bin/smsreport createpartition 7

# Запускаем крон
echo "RUN CRON"
service cron start
service cron status

# Запускаем memcached
echo "RUN MEMCACHED"
service memcached start
service memcached status

# Запускаем celery
echo "RUN CELERY"
/etc/init.d/celeryd start
/etc/init.d/celeryd status

# Стартуем сервер
echo "START SERVER"
