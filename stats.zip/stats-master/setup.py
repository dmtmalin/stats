#!/usr/bin/env python
import os
import sys

from setuptools import setup, find_packages, Command

sys.path.insert(0, 'src')

with open(os.path.join(os.path.dirname(__file__), 'README.md')) as readme:
    README = readme.read()

'''
class BowerInstallCommand(Command):
    user_options = []

    description = 'run bower install command'

    def initialize_options(self):
        pass

    def finalize_options(self):
        pass

    def run(self):
        cmd = ['bower', 'install', '--allow-root']
        self.spawn(cmd)
'''

requires = [
    'Django==1.9.9',
    'psycopg2==2.8.3',
    'django-filter==1.0.4',
    'django-picklefield==0.3.2',
    'django-constance[database]==2.0.0',
    'python-dateutil==2.6.0',
    'django-grappelli==2.9.1',
    'django-queryset-csv==1.0.0',
    'smpp.pdu==0.3',
    'python-memcached==1.58',
    'celery==3.1.25',
    'django-celery==3.2.1',
    'redis==2.10.5',
    'celery-redis-sentinel==0.3.0',
]

setup(
    name='smsreport',
    version='0.0.2',
    keywords='web django',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    url='https://stat.smslab.ru',
    license='BSD License',
    author='d.malinin',
    author_email='d.malinin@i-teco.ru',
    description='Sms stats project',
    long_description=README,
    include_package_data=True,
    install_requires=requires,
    entry_points={
        'console_scripts': [
            'smsreport = smsreport.manage:main',
        ]
    },
    #cmdclass={
    #    'bower_install': BowerInstallCommand,
    #},
    classifiers=[
        'Environment :: Web Environment',
        'Framework :: Django',
        'Framework :: Django :: 1.9',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: BSD License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 2.7',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Internet :: WWW/HTTP :: Dynamic Content',
    ],
)
