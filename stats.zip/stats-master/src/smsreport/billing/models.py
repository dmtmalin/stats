# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
from smsreport.account.models import User


# история пополнений
class Debit(models.Model):
    value = models.DecimalField(u'Значение', max_digits=13, decimal_places=2)
    created_at = models.DateTimeField(u'Создано', auto_now_add=True, db_index=True)
    user = models.ForeignKey(User)

    class Meta:
        verbose_name = u'Поступление'
        verbose_name_plural = u'Поступления'

    def __unicode__(self):
        return str(self.value)


# расходы
class Credit(models.Model):
    value = models.DecimalField(u'Значение', max_digits=13, decimal_places=2)
    created_at = models.DateTimeField(u'Создано', auto_now_add=True, db_index=True)
    user = models.ForeignKey(User)

    class Meta:
        verbose_name = u'Расходы'
        verbose_name_plural = u'Расходы'

    def __unicode__(self):
        return str(self.value)


# баланс
class Balance(models.Model):
    value = models.DecimalField(u'Баланс', max_digits=13, decimal_places=2)
    updated_at = models.DateTimeField(u'Изменено', auto_now=True, db_index=True)
    created_at = models.DateTimeField(u'Создано', auto_now_add=True, db_index=True)
    user = models.OneToOneField(User, related_name='balance')

    class Meta:
        verbose_name = u'Баланс'
        verbose_name_plural = u'Баланс'

    def __unicode__(self):
        return str(self.value)
