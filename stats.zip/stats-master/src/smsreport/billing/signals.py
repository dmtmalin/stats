# -*- coding: utf-8 -*-
from django.db.models.signals import post_save
from django.dispatch import receiver
from decimal import Decimal
from smsreport.billing.models import *


# изменение баланса при пополнении
@receiver(post_save, sender=Debit)
def change_balance_by_debit(sender, instance, *args, **kwargs):
    balance, created = Balance.objects.get_or_create(user=instance.user, defaults={'value': 0})
    balance.value += Decimal(instance.value)
    balance.save()


# изменение баланса при списании
@receiver(post_save, sender=Credit)
def change_balance_by_credit(sender, instance, *args, **kwargs):
    balance, created = Balance.objects.get_or_create(user=instance.user, defaults={'value': 0})
    balance.value -= Decimal(instance.value)
    balance.save()

