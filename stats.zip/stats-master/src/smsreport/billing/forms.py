# -*- coding: utf-8 -*-
from django import forms
from smsreport.billing.models import Debit


# отсеивает данные, которые будут редактироваться через форму
class AddEditDebitForm(forms.ModelForm):

    def clean(self):
        if 'id' in self.cleaned_data and self.cleaned_data['id'] and 'value' in self.changed_data:
            valid_value = self.instance.value
            raise forms.ValidationError(u'Изменение у.е. невозможно. Валидное значение %s' % (valid_value, ))
        return super(AddEditDebitForm, self).clean()

    class Meta:
        model = Debit
        fields = ('id', 'value', 'user',)
