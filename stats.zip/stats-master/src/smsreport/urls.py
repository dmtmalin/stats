# -*- coding: utf-8 -*-
"""smsreport URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
from django.core.urlresolvers import reverse_lazy
from django.views.generic.base import RedirectView

from smsreport.account.views import login_view, logout_view
from smsreport.mailing.views import CreateMailing, MailingList, CreateMailingFromFile
from smsreport.report.views import ReportView, ResendArchiveView, ResendQueueView, ReportViewCsv
from smsreport.sms.views import ResendSmsAction, MassResendSmsAction, SmsView, LostView
from smsreport.archive.views import CreateArchive

urlpatterns = [
    url(r'^grappelli/', include('grappelli.urls')),
    url(r'^admin/', admin.site.urls),
    url(r'^$', RedirectView.as_view(url=reverse_lazy('report_view')), name='home_view'),
    url(r'^report/$', ReportView.as_view(), name='report_view'),
    url(r'^report/csv/$', ReportViewCsv.as_view(), name='report_csv_view'),
    url(r'^lost/$', LostView.as_view(), name='lost_view'),
    url(r'^login/$', login_view, name='login_view'),
    url(r'^send-sms/$', ResendSmsAction.as_view(), name='send_sms'),
    url(r'^send-mass-sms/$', MassResendSmsAction.as_view(), name='mass_send_sms'),
    url(r'^resend/$', ResendArchiveView.as_view(), name='resend_view'),
    url(r'^resend/queue/$', ResendQueueView.as_view(), name='resend_queue_view'),
    url(r'^logout/$', logout_view, name='logout_view'),
    url(r'^sms/$', SmsView.as_view(), name='sms_view'),
    url(r'^mailing/$', MailingList.as_view(), name='mailing'),
    url(r'^mailing/create/$', CreateMailing.as_view(), name='create_mailing'),
    url(r'^mailing/filecreate/$', CreateMailingFromFile.as_view(), name='create_mailing_from_file'),
    url(r'^admin/archive/create/(?P<type>\d+)/$', view=CreateArchive.as_view(), name='create_archive'),
]
