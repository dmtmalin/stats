# -*- coding: utf-8 -*-
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, logout
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect
from django.views.decorators.debug import sensitive_post_parameters
from django.views.generic import FormView

sensitive_post_parameters_decorator = sensitive_post_parameters('password')


class Login(FormView):
    form_class = AuthenticationForm
    template_name = 'home.html'

    def form_valid(self, form):
        redirect_to = reverse('home_view')
        login(self.request, form.get_user())
        return HttpResponseRedirect(redirect_to)

    def form_invalid(self, form):
        return self.render_to_response(self.get_context_data(form=form))


login_view = sensitive_post_parameters_decorator(Login.as_view())


def logout_view(request):
    logout(request)
    redirect_to = reverse('home_view')
    return HttpResponseRedirect(redirect_to)
