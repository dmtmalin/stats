# -*- coding: utf-8 -*-
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.core.paginator import EmptyPage, InvalidPage, Paginator

from smsreport.account.models import User
from smsreport.billing.models import Balance, Debit, Credit
from smsreport.billing.forms import AddEditDebitForm


# баланс в административной панели
class BalanceInline(admin.TabularInline):
    model = Balance
    can_delete = False
    list_display = ('value', 'created_at', )
    readonly_fields = ('value', 'created_at', 'updated_at')

    def has_add_permission(self, request):
        return False


# история пополнения баланса в административной модели
class DebitInline(admin.TabularInline):
    model = Debit
    extra = 1
    can_delete = False
    form = AddEditDebitForm
    list_display = ('value', 'created_at', )
    readonly_fields = ('created_at', )
    ordering = ('-created_at', )
    template = 'admin/tabular_paginated.html'
    per_page = 20

    # для ограничения количества отображаемых данных на странице
    def get_formset(self, request, obj=None, **kwargs):
        formset_class = super(DebitInline, self).get_formset(request, obj, **kwargs)

        class PaginationFormSet(formset_class):
            def __init__(self, *args, **kwargs):
                super(PaginationFormSet, self).__init__(*args, **kwargs)

                qs = self.get_queryset()
                paginator = Paginator(qs, self.per_page)
                try:
                    page_num = int(request.GET.get('page', '1'))
                except ValueError:
                    page_num = 1

                try:
                    page = paginator.page(page_num)
                except (EmptyPage, InvalidPage):
                    page = paginator.page(paginator.num_pages)

                self.paginator = paginator
                self.page = page
                self._queryset = page.object_list

        PaginationFormSet.per_page = self.per_page
        return PaginationFormSet


# история расходов в административной модели
class CreditInline(admin.TabularInline):
    model = Credit
    extra = 0
    can_delete = False
    list_display = ('value', 'updated_at', 'created_at', 'user',)
    readonly_fields = ('value', 'created_at',)
    ordering = ('-created_at',)
    template = 'admin/tabular_paginated.html'
    per_page = 20

    def has_add_permission(self, request):
        return False

    # для ограничения количества отображаемых данных на страниц
    def get_formset(self, request, obj=None, **kwargs):
        formset_class = super(CreditInline, self).get_formset(request, obj, **kwargs)

        class PaginationFormSet(formset_class):
            def __init__(self, *args, **kwargs):
                super(PaginationFormSet, self).__init__(*args, **kwargs)

                qs = self.get_queryset()
                paginator = Paginator(qs, self.per_page)
                try:
                    page_num = int(request.GET.get('page', '1'))
                except ValueError:
                    page_num = 1

                try:
                    page = paginator.page(page_num)
                except (EmptyPage, InvalidPage):
                    page = paginator.page(paginator.num_pages)

                self.paginator = paginator
                self.page = page
                self._queryset = page.object_list

        PaginationFormSet.per_page = self.per_page
        return PaginationFormSet


class AccountAdmin(UserAdmin):

    def get_fieldsets(self, request, obj=None):
        t = super(AccountAdmin, self).get_fieldsets(request, obj)
        if obj is not None and not obj.is_staff:
            l = list(t)
            l.insert(2, self.user_fieldsets)
            return tuple(l)
        return t

    user_fieldsets = (u'Отображение статистики', {'fields': ('source_connector', 'source')})

    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        (u'Персональная информация', {'fields': ('email',)}),
        (u'Администрирование', {'fields': ('is_staff', 'is_superuser', )}),
        (u'История', {'fields': ('last_login', 'date_joined',)}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'source_connector', 'source', 'password1', 'password2',)}
         ),
    )
    list_display = ('id', 'username', 'email', 'is_active', 'is_staff', 'source_connector', 'source', 'balance',)
    readonly_fields = ('last_login', 'date_joined',)
    ordering = ('username', )
    inlines = (BalanceInline, DebitInline, CreditInline, )


admin.site.register(User, AccountAdmin)
