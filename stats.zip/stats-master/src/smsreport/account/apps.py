from __future__ import unicode_literals

from django.apps import AppConfig


class ProfileauthConfig(AppConfig):
    name = 'smsreport.account'

    def ready(self):
        import smsreport.account.signals
