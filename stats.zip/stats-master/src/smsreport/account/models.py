# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    source_connector = models.CharField(u'Фильтр по коннектору', max_length=512, null=True, blank=True,
                                        help_text=u'<имя> - показать для коннектора, '
                                                  u'!<имя> - исключить для коннектора, '
                                                  u'~<имя> - показать для коннекторов начинающихся с <имя>'
                                                  u'<пустое поле> - все коннекторы. Указывается через разделитель.')
    source = models.CharField(u'Фильтр по подпси', max_length=512, null=True, blank=True,
                              help_text=u'<имя> - статистика для подписи, '
                                        u'!<имя> - исключить для подписи, '
                                        u'~<имя> - показать для подписей начинающихся с <имя>'
                                        u'<пустое поле> - все подписи. Указывается через разделитель.')
