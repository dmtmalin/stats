# -*- coding: utf-8 -*-
from django.db.models.signals import post_save
from django.dispatch import receiver
from smsreport.account.models import User
from smsreport.billing.models import Balance


# создаём баланс для пользователя, если его нет
@receiver(post_save, sender=User)
def create_balance_for_user(sender, instance, *args, **kwargs):
    Balance.objects.get_or_create(user=instance, defaults={'value': 0})
