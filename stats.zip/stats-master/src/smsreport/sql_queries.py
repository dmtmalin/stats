# -*- coding: utf-8 -*-
SELECT_TABLE_NAME = 'SELECT relname FROM pg_class WHERE relname=%(table_name)s;'

CREATE_PARTITION_SQL = '''
CREATE TABLE %(partition_table)s (
  CHECK (create_time >= %(check_from)s and create_time < %(check_to)s)
)
INHERITS (%(master_table)s);

ALTER TABLE %(partition_table)s ADD CONSTRAINT %(partition_table)s_pkey PRIMARY KEY(id);

CREATE INDEX %(partition_table)s_message_id ON %(partition_table)s USING btree (message_id);
CREATE INDEX %(partition_table)s_message_id_like ON %(partition_table)s USING btree (message_id varchar_pattern_ops);
CREATE INDEX %(partition_table)s_remote_message_id ON %(partition_table)s USING btree (remote_message_id);
CREATE INDEX %(partition_table)s_remote_message_id_like ON %(partition_table)s USING btree (remote_message_id varchar_pattern_ops);
CREATE INDEX %(partition_table)s_destination ON %(partition_table)s USING btree (destination);
CREATE INDEX %(partition_table)s_destination_like ON %(partition_table)s USING btree (destination varchar_pattern_ops);
CREATE INDEX %(partition_table)s_source ON %(partition_table)s USING btree (source);
CREATE INDEX %(partition_table)s_source_like ON %(partition_table)s USING btree (source varchar_pattern_ops);
CREATE INDEX %(partition_table)s_source_connector ON %(partition_table)s USING btree (source_connector);
CREATE INDEX %(partition_table)s_source_connector_like ON %(partition_table)s USING btree (source_connector varchar_pattern_ops);
CREATE INDEX %(partition_table)s_create_time ON %(partition_table)s USING btree (create_time);
CREATE INDEX %(partition_table)s_status ON %(partition_table)s USING btree (status);
CREATE INDEX %(partition_table)s_delivery_status ON %(partition_table)s USING btree (delivery_status);
CREATE INDEX %(partition_table)s_operator_id ON %(partition_table)s USING btree (operator_id);
'''

CREATE_TRIGGER_INSERT_CHILD = '''
CREATE OR REPLACE FUNCTION %(master_table)s_insert_child()
RETURNS TRIGGER AS $$
DECLARE
  partition_table VARCHAR(255);
BEGIN
  partition_table := '%(master_table)s_' || TO_CHAR(NEW.create_time, '"y"YYYY"m"MM"d"DD');
  EXECUTE 'INSERT INTO ' || partition_table || ' VALUES (($1).*);' USING NEW;
  RETURN NULL;
END;
$$
LANGUAGE plpgsql;

CREATE TRIGGER before_insert_%(master_table)s_trigger
    BEFORE INSERT ON %(master_table)s
    FOR EACH ROW EXECUTE PROCEDURE %(master_table)s_insert_child();
'''

DROP_PRIMARY_KEY = 'ALTER TABLE %(drop_table)s DROP CONSTRAINT IF EXISTS %(drop_table)s_pkey;'

AGGREGATE_SMS_FOR_PARTITION = '''
SELECT
  %(partition_table)s."operator_id",  
  %(partition_table)s."source",
  %(partition_table)s."source_connector",
  %(partition_table)s."status",
  %(partition_table)s."delivery_status",
  COUNT(%(partition_table)s."id") AS "count"
FROM
  %(partition_table)s
GROUP BY
  %(partition_table)s."operator_id",
  %(partition_table)s."source",
  %(partition_table)s."source_connector",
  %(partition_table)s."status",
  %(partition_table)s."delivery_status";
'''

SELECT_SMS = '''
SELECT
  %(partition_table)s."id",
  %(partition_table)s."message_id",  
  %(partition_table)s."remote_message_id",
  %(partition_table)s."message",
  %(partition_table)s."source_connector",   
  %(partition_table)s."routed_cid",
  %(partition_table)s."destination",
  %(partition_table)s."source",
  %(partition_table)s."pdu_count",
  %(partition_table)s."status",
  %(partition_table)s."create_time",  
  %(partition_table)s."submit_time",
  %(partition_table)s."submit_response_time",
  %(partition_table)s."delivery_report_time",
  %(partition_table)s."delivery_time",
  %(partition_table)s."delivery_status",
  %(partition_table)s."delivery_err",
  %(partition_table)s."send_attempt",
  %(partition_table)s."operator_id"
FROM %(partition_table)s
ORDER BY %(partition_table)s."submit_time"
LIMIT %(limit)s OFFSET %(offset)s;
'''


SELECT_NEXT_ID = '''
SELECT nextval(pg_get_serial_sequence(%(table)s, 'id'));
'''

SELECT_SMS_WHERE_PDU_AND_SOURCE = '''
SELECT
  %(partition_table)s."id",
  %(partition_table)s."message_id",  
  %(partition_table)s."remote_message_id",
  %(partition_table)s."message",
  %(partition_table)s."source_connector",   
  %(partition_table)s."routed_cid",
  %(partition_table)s."destination",
  %(partition_table)s."source",
  %(partition_table)s."pdu_count",
  %(partition_table)s."status",
  %(partition_table)s."create_time",  
  %(partition_table)s."submit_time",
  %(partition_table)s."submit_response_time",
  %(partition_table)s."delivery_report_time",
  %(partition_table)s."delivery_time",
  %(partition_table)s."delivery_status",
  %(partition_table)s."delivery_err",
  %(partition_table)s."send_attempt",
  %(partition_table)s."operator_id"
FROM %(partition_table)s
WHERE 
  (%(pdu_count)s IS NULL OR %(partition_table)s."pdu_count" = %(pdu_count)s) AND
  (%(source)s IS NULL OR %(partition_table)s."source" = %(source)s)
ORDER BY %(partition_table)s."submit_time"
LIMIT %(limit)s OFFSET %(offset)s;
'''
