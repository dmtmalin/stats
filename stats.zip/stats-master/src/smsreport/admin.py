# -*- coding: utf-8 -*-
import re
from django import forms
from django.contrib import admin
from constance.admin import ConstanceAdmin, ConstanceForm, Config

from smsreport.utils import validate_phone_numbers


class CustomConfigForm(ConstanceForm):
    def __init__(self, *args, **kwargs):
        super(CustomConfigForm, self).__init__(*args, **kwargs)

    def clean_RESEND_SMS_NUMBERS(self):
        data = self.cleaned_data['RESEND_SMS_NUMBERS']
        if 'RESEND_SMS_NUMBERS' in self.changed_data and data:
            validate_phone_numbers(data)
        return data

    def clean_SOURCES_FOR_MAILING(self):
        data = self.cleaned_data['SOURCES_FOR_MAILING']
        if 'SOURCES_FOR_MAILING' in self.changed_data and data:
            sources = re.findall(r"[\w']+", data)
            if not sources:
                raise forms.ValidationError(u'Подписи в тексте %s не найдены' % (data,))
        return data

    def clean_SMS_PRICE(self):
        data = self.cleaned_data.get('SMS_PRICE')
        if data < 0:
            raise forms.ValidationError(u'Стоимость СМС меньше 0')
        if round(data, 2) == 0:
            raise forms.ValidationError(u'Минимальная стоимость СМС: 0.01 у.е.')

        return data


class ConfigAdmin(ConstanceAdmin):
    change_list_form = CustomConfigForm


admin.site.unregister([Config])
admin.site.register([Config], ConfigAdmin)
