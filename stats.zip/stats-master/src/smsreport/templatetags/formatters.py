# -*- coding: utf-8 -*-
import re
import codecs
from django import template
from smpp.pdu.error import SMPPError
from StringIO import StringIO
from smpp.pdu.pdu_encoding import PDUEncoder

register = template.Library()


@register.filter(name='subtract')
def subtract(value, arg):
    return value - arg


@register.filter(name='htmlattributes')
def add_html_attributes(field, value):
    attrs = eval(value)
    return field.as_widget(attrs=attrs)


@register.filter(name='split')
def split(value):
    return value.split()


@register.filter(name='percentage')
def percentage(part, whole):
    try:
        percent = float(part) / float(whole)
        return "{:.1%}".format(percent)
    except ZeroDivisionError:
        return ''


@register.filter(name='pdudecode')
def pdu_decode(buff):
    io = StringIO(buff)
    pdu = None
    try:
        pdu = PDUEncoder().decode(io)
    except SMPPError:
        pass
    message = ''
    if pdu:
        bytes_message = pdu.params['short_message']
        message = codecs.decode(bytes_message, 'utf-16-be', 'ignore')
    return message


@register.filter(name='join_lines')
def join_lines(value):
    return '\n'.join(value)
