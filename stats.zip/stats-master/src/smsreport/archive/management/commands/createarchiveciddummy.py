# -*- coding: utf-8 -*-
import os
import zipfile
from random import shuffle
from django.core.management import BaseCommand
from smsreport.archive.models import Archive
from dateutil.parser import parse
from datetime import datetime
from smsreport.sms.models import Sms
from smsreport.sms.utils import db_table_exists
from smsreport.sql_queries import SELECT_SMS_WHERE_PDU_AND_SOURCE
from psycopg2.extensions import AsIs
from django.db import connection

from smsreport.templatetags.formatters import pdu_decode
from smsreport.utils import dictfetchall


class Command(BaseCommand):
    help = 'Create archive replace routed_cid by percent'

    def add_arguments(self, parser):
        parser.add_argument('date', type=str)
        parser.add_argument(
            '--routed_cid_group',
            dest='routed_cid_group',
            default='',
            type=str
        )
        parser.add_argument(
            '--need',
            dest='need',
            default=0,
            type=int
        )
        parser.add_argument(
            '--save_path',
            dest='save_path',
            default='',
            type=str
        )
        parser.add_argument(
            '--source',
            dest='source',
            default=None,
            type=str
        )

    def handle(self, *args, **options):
        date = options['date']
        try:
            build_for = parse(date) if date else datetime.now()
        except ValueError:
            return self.stdout.write(self.style.WARNING('Unknown string format for date. Abort.'))
        try:
            routed_cid_group = {opt[0]: float(opt[1]) for opt in
                                [opt.split(':') for opt in
                                 [opt for opt in options['routed_cid_group'].split(',')]]}
        except (ValueError, IndexError):
            return self.stdout.write(self.style.WARNING("Can't parse routed_cid_group parameter. Abort."))
        partition_table = '%s_%s' % (Sms.objects.model._meta.db_table, build_for.strftime('y%Ym%md%d'),)

        if not db_table_exists(partition_table):
            return self.stdout.write(self.style.WARNING('Relation %s is not exists. Abort.' % (partition_table,)))

        self.stdout.write(self.style.SUCCESS('Create dummy cid archive for %s') % (build_for.date(),))
        limit = options['need'] * 100 / sum([v for k, v in routed_cid_group.iteritems()])
        limit = int(round(limit, 0))

        with connection.cursor() as cursor:
            cursor.execute(SELECT_SMS_WHERE_PDU_AND_SOURCE, {
                'partition_table': AsIs(partition_table),
                'source': options['source'],
                'pdu_count': 1,
                'offset': 0,
                'limit': limit
            })
            rows = dictfetchall(cursor)
            # decode pdu
            for i, row in enumerate(rows):
                if row['message'] is not None:
                    rows[i]['message'] = pdu_decode(row['message'])
        if len(rows) < limit:
            return self.style.WARNING("In relation %s not need sms records. Abort." % (partition_table,))
        # mix rows
        shuffle(rows)
        len_rows = len(rows)
        groups_rows = []
        for key, value in routed_cid_group.iteritems():
            len_part = int(round(len_rows * value / 100, 0))
            if len_part == 0:
                len_part = 1
            rows_part = rows[0:len_part]
            for i, row_part in enumerate(rows_part):
                rows_part[i]['routed_cid'] = key
            del rows[0:len_part]
            groups_rows.append(rows_part)
        new_rows = []
        for group_rows in groups_rows:
            new_rows += group_rows
        new_rows.sort(key=lambda r: r['submit_time'])
        filename = os.path.join(options['save_path'], '%s_%07d.csv' % (build_for.date(), len(new_rows)))
        with open(filename, 'wb') as f:
            header = ';'.join(['"%s"' % (key,) for key in new_rows[0].keys()]) + '\n'
            body = '\n'.join(
                [';'.join(['""' if value is None else '"%s"' % (value,) for k, value in new_row.iteritems()])
                 for new_row in new_rows]) + '\n'
            csv = header + body
            # write for windows Excel
            f.write(csv.encode('cp1251', 'ignore'))
        archive_name = os.path.join(options['save_path'], 'dummy_cid_archive_%s.zip' % (build_for.date(),))
        with zipfile.ZipFile(archive_name, 'w') as z:
            z.write(filename, os.path.basename(filename), compress_type=zipfile.ZIP_DEFLATED)
            size = sum([info.file_size for info in z.filelist])
            archive_size = float(size) / 1000  # kB
        if os.path.isfile(filename):
            os.remove(filename)
        archive = Archive(path_to_file=archive_name, description=u'Dummy cid архив %s' % (build_for.date()),
                          size=archive_size, rows_count=len(new_rows), type=1)
        archive.save()
        self.stdout.write(self.style.SUCCESS('Finish build dummy cid archive'))
