# -*- coding: utf-8 -*-
import random
import time
import os
import csv
import zipfile
import sys
import uuid
from django.core.management.base import BaseCommand
from django.db import connection
from psycopg2.extensions import AsIs
from itertools import izip_longest
from dateutil.parser import parse
from dateutil.relativedelta import relativedelta
from datetime import datetime
from smsreport.sms.utils import db_table_exists
from smsreport.sms.models import Sms
from smsreport.archive.models import Archive, GENERATED_EXPANDED_TYPE

# --save_path - русских символов в пути не должно быть
# --sms_spreading - расспределение смс по равным промежуткам времени

# генерация расширенного отчёта


class Command(BaseCommand):
    help = 'Create sms and ussd in and out report for time period'

    def add_arguments(self, parser):
        now = datetime.today()
        end = now + relativedelta(months=-1)
        parser.add_argument('--sms_in_count', dest='sms_in_count', default=100, type=int)
        parser.add_argument('--sms_out_count', dest='sms_out_count', default=100, type=int)
        parser.add_argument('--ussd_in_count', dest='ussd_in_count', default=100, type=int)
        parser.add_argument('--ussd_out_count', dest='ussd_out_count', default=100, type=int)
        parser.add_argument('--count_in_file', dest='count_in_file', default=1000000, type=int)
        parser.add_argument('--datetime_start', dest='datetime_start', default=end.__str__(), type=str)
        parser.add_argument('--datetime_end', dest='datetime_end', default=now.__str__(), type=str)
        parser.add_argument('--save_path', dest='save_path', default='/archive', type=str)
        parser.add_argument('--sms_spreading', dest='sms_spreading', default="54,54,52,53,55,54,52,53,54,55,54,55,53,"
                                                                             "54,55,53,54,55,54,53,54,53,52,54,54,55,"
                                                                             "53,54,54,53,55,54", type=str)

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Start create report'))
        start_command = datetime.now()
        self.stdout.write(self.style.ERROR("Generate report starts in %s" % start_command))

        try:
            sms_in_count = options['sms_in_count']
            sms_out_count = options['sms_out_count']
            ussd_in_count = options['ussd_in_count']
            ussd_out_count = options['ussd_out_count']
            tmp_sms_in_count = int(options['sms_in_count'])
            tmp_sms_out_count = int(options['sms_out_count'])
            tmp_ussd_in_count = int(options['ussd_in_count'])
            tmp_ussd_out_count = int(options['ussd_out_count'])
            count_in_file = int(options['count_in_file'])
            summary_count = sms_in_count + sms_out_count + ussd_in_count + ussd_out_count
            datetime_start = options['datetime_start']
            datetime_end = options['datetime_end']
            save_path = options['save_path']
            sms_spreading = options['sms_spreading'].split(',')
            for i in range(len(sms_spreading)):
                sms_spreading[i] = int(sms_spreading[i])
            datetime_start = parse(datetime_start, ignoretz=True) if datetime_start else datetime.now()
            datetime_end = parse(datetime_end, ignoretz=True) if datetime_end else datetime.now() + relativedelta(days=-1)

            self.stdout.write(self.style.SUCCESS(
                'SMS in: %s. SMS out: %s. USSD in: %s. USSD out: %s.Start Date: %s. End Date: %s. Path: %s.')
                              % (
                              sms_in_count, sms_out_count, ussd_in_count, ussd_out_count, datetime_start, datetime_end,
                              save_path))
            if datetime_start > datetime_end:
                tempdate = datetime_end
                datetime_end = datetime_start
                datetime_start = tempdate
            datetime_end += relativedelta(seconds=-1)
        except ValueError:
            self.stdout.write(self.style.SUCCESS(
                'SMS in: %s. SMS out: %s. USSD in: %s. USSD out: %s.Start Date: %s. End Date: %s. Path: %s.')
                              % (
                              sms_in_count, sms_out_count, ussd_in_count, ussd_out_count, datetime_start, datetime_end,
                              save_path))
            e = sys.exc_info()[1]
            self.stdout.write(self.style.ERROR(e.args[0]))
            return self.stdout.write(self.style.ERROR('Unknown string format for date or counters. Abort.'))
        except:
            e = sys.exc_info()[1]
            self.stdout.write(self.style.ERROR(e.args[0]))
            return self.stdout.write(self.style.ERROR('Unknown exception for arguments. Abort.'))

        try:
            totalminuts = (datetime_end - datetime_start).total_seconds() / 60
            start_dt = datetime_start
            filenames = []
            # вычисляем временные рамки для периода
            start_period = start_dt
            end_period = start_period + relativedelta(minutes=totalminuts)
            start_dt = end_period
            # достаём данные по смс из БД
            partition_table = '%s' % (Sms.objects.model._meta.db_table,)
            if not db_table_exists(partition_table):
                partition_table = '%s_%s' % (Sms.objects.model._meta.db_table, start_period.strftime('y%Ym%md%d'),)
                if not db_table_exists(partition_table):
                    return self.stdout.write(self.style.ERROR('Table %s is not exists. Abort.' % (partition_table,)))
            query = """
                  SELECT
                      routed_cid,
                      destination,
                      '',
                      '',
                      ''
                  FROM %(partition_table)s
                  WHERE create_time > %(start_period)s AND create_time < %(end_period)s
                  LIMIT %(limit)s;"""
            with connection.cursor() as cursor:
                cursor.execute(query, {'partition_table': AsIs(partition_table), 'limit': summary_count,
                                       'start_period': start_period, 'end_period': end_period})
                rows = cursor.fetchall()
            if len(rows) == 0:
                with connection.cursor() as cursor:
                    cursor.execute(query, {'partition_table': AsIs(partition_table), 'limit': summary_count,
                                           'start_period': datetime_start, 'end_period': datetime_end})
                    rows = cursor.fetchall()
                if len(rows) == 0:
                    return self.stdout.write(self.style.ERROR('There are no data for this period. Abort.'))
            # добавляем недостающие в БД СМС
            need_add_count = summary_count - len(rows)
            for rr in range(int(need_add_count)):
                rand_row = rows[random.randint(0, len(rows) - 1)]
                if rand_row is not None:
                    rand_row = list(rand_row)
                    rand_row[1] = get_random_tel()
                rows.append(rand_row)

            # распределяем смс согласно массиву распределения, выставляем Тип и Направление и рандомим время
            if sum(sms_spreading) > summary_count:
                sms_spreading = [1]
            spr_sms_count_part = summary_count / float(sum(sms_spreading))
            tmp_dt = start_period
            spr_counter = 0
            for spr in range(len(sms_spreading)):
                spr_st_dt = tmp_dt
                spr_end_dt = spr_st_dt + relativedelta(minutes=totalminuts / len(sms_spreading))
                tmp_dt = spr_end_dt
                if spr == len(sms_spreading) - 1:
                    sms_spreading[spr] = 0
                    sms_spreading[spr] = summary_count - sum(sms_spreading)
                else:
                    sms_spreading[spr] = round(spr_sms_count_part * sms_spreading[spr])

                for spr_index in range(int(sms_spreading[spr])):
                    appended_row = list(rows[spr_counter])
                    rnd_date = rand_dt(spr_st_dt, spr_end_dt, random.random()) + relativedelta(seconds=random.uniform(0.0, 1.0))

                    rnd_route = get_random_route(tmp_sms_in_count + tmp_ussd_in_count,
                                                 tmp_sms_out_count + tmp_ussd_out_count)
                    if rnd_route == "In":
                        rnd_type = get_random_type(tmp_sms_in_count, tmp_ussd_in_count)
                    else:
                        rnd_type = get_random_type(tmp_sms_out_count, tmp_ussd_out_count)
                        appended_row[4] = "7377"
                    appended_row[2] = rnd_type
                    appended_row[3] = rnd_route
                    appended_row.append(rnd_date)

                    rows[spr_counter] = appended_row
                    if appended_row[3] == "In" and appended_row[2] == "SMS":
                        tmp_sms_in_count = tmp_sms_in_count - 1
                    elif appended_row[3] == "Out" and appended_row[2] == "SMS":
                        tmp_sms_out_count = tmp_sms_out_count - 1
                    elif appended_row[3] == "In" and appended_row[2] == "USSD":
                        tmp_ussd_in_count = tmp_ussd_in_count - 1
                    elif appended_row[3] == "Out" and appended_row[2] == "USSD":
                        tmp_ussd_out_count = tmp_ussd_out_count - 1
                    spr_counter = spr_counter + 1

            # сортируем данные по времени сообщения
            rows.sort(key=lambda r: r[5])

            # правильно выстраиваем данные - через несколько после входящего сообщения один/несколько ответов
            smsInList = []
            ussdInList = []
            for item in range(len(rows)):
                if rows[item][2] == "SMS" and rows[item][3] == "In":
                    smsIn = []
                    smsIn.append(rows[item][0])
                    smsIn.append(rows[item][1])
                    smsIn.append(rows[item][5])
                    smsIn.append(random.randint(1, 2))
                    smsInList.append(smsIn)
                elif rows[item][2] == "USSD" and rows[item][3] == "In":
                    ussdIn = []
                    ussdIn.append(rows[item][0])
                    ussdIn.append(rows[item][1])
                    ussdIn.append(rows[item][5])
                    if len(ussdIn) < 20:
                        ussdIn.append(random.randint(2, 3))
                    else:
                        ussdIn.append(random.randint(1, 2))
                    ussdInList.append(ussdIn)
                elif rows[item][2] == "SMS" and rows[item][3] == "Out":
                    if len(smsInList) != 0:
                        rows[item][0] = smsInList[0][0]
                        rows[item][1] = smsInList[0][1]
                        rows[item][5] = smsInList[0][2] + relativedelta(seconds=random.uniform(0.9, 6.9))
                        if rows[item][5] >= datetime_end:
                            rows[item][1] = get_random_tel()
                            rows[item][5] = datetime_start + relativedelta(seconds=random.uniform(0.1, 1.5))
                        smsInList[0][3] = smsInList[0][3] - 1
                        if smsInList[0][3] == 0:
                            smsInList.pop(0)

                elif rows[item][2] == "USSD" and rows[item][3] == "Out":
                    if len(ussdInList) != 0:
                        if len(ussdInList) > 1:
                            ussdInList.pop(0)
                        rows[item][0] = ussdInList[0][0]
                        rows[item][1] = ussdInList[0][1]
                        rows[item][5] = ussdInList[0][2] + relativedelta(seconds=random.uniform(0.9, 5.6))
                        if rows[item][5] >= datetime_end:
                            rows[item][1] = get_random_tel()
                            rows[item][5] = datetime_start + relativedelta(seconds=random.uniform(0.1, 1.5))
                        ussdInList[0][3] = ussdInList[0][3] - 1
                        if ussdInList[0][3] == 0:
                            if len(ussdInList) != 1:
                                ussdInList.pop(0)
            rows.sort(key=lambda r: r[5])

            # записываем в файл по 1 000 000 строк
            groups = grouper(count_in_file, rows, fillvalue='')
            for i, gg in enumerate(groups):
                filename = os.path.join(save_path, '%s_%s_%07d.csv'  # %s
                                        % (datetime_start.date(), datetime_end.date(), i))  # , index
                with open(filename, 'wb', zipfile.ZIP_DEFLATED) as f:
                    writer = csv.writer(f)
                    writer.writerows([x for x in gg if x])  # избавляемся от пустых элементов
                    filenames.append(filename)
            # формируем единый архив
            archive_name = os.path.join(save_path, '%s_%s_%s.zip' % (datetime_start.date(), datetime_end.date(), uuid.uuid4().hex))
            with zipfile.ZipFile(archive_name, 'w') as z:
                for filename in filenames:
                    z.write(filename, os.path.basename(filename), compress_type=zipfile.ZIP_DEFLATED)
                size = sum([info.file_size for info in z.filelist])
                archive_size = float(size) / 1000  # kB
            for filename in filenames:
                if os.path.isfile(filename):
                    os.remove(filename)
            archive = Archive(path_to_file=archive_name, description=get_description(datetime_start, datetime_end),
                              size=archive_size, rows_count=len(rows), type=GENERATED_EXPANDED_TYPE)
            archive.save()

            self.stdout.write(self.style.SUCCESS('Finish build report'))
            end_command = datetime.now()
            self.stdout.write(self.style.ERROR("Generate report ends in %s. Total time: %s" %
                                               (end_command, end_command - start_command)))

        except Exception:
            e = sys.exc_info()[1]
            for item in e.args:
                self.stdout.write(self.style.ERROR(item.__str__()))
            return self.stdout.write(self.style.ERROR('Unknown exception. Abort.'))


def get_description(datetime_start, datetime_end):
    return u'Сгенерированный расширенный архив %s - %s' % (datetime_start.date(), datetime_end.date())


def rand_dt(start, end, prop):
    stime = time.mktime(start.timetuple()) + start.microsecond / 1E6
    etime = time.mktime(end.timetuple()) + end.microsecond / 1E6
    ptime = stime + prop * (etime - stime)
    return datetime.fromtimestamp(time.mktime(time.localtime(ptime)))


def gen_iter():
    i = 0
    while True:
        i += 1
        yield i


def grouper(n, iterable, fillvalue=None):
    args = [iter(iterable)] * n
    return izip_longest(fillvalue=fillvalue, *args)


def get_random_type(sms_count, ussd_count):
    total_count = sms_count + ussd_count
    rnd = random.randint(1, total_count)
    if rnd <= sms_count:
        return "SMS"
    return "USSD"


def get_random_route(in_count, out_count):
    total_count = in_count + out_count
    rnd = random.randint(1, total_count)
    if rnd <= in_count:
        return "In"
    return "Out"


def get_random_tel():
    operators_codes = (900, 901, 902, 903, 904, 905, 906, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919,
                       920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 936, 937, 938, 939,
                       941, 950, 951, 952, 953, 954, 955, 956, 958, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969,
                       970, 971, 977, 978, 980, 981, 982, 983, 984, 985, 986, 987, 988, 989, 991, 992, 993, 994, 995,
                       996, 997, 999)
    operator_code = operators_codes[random.randint(0, len(operators_codes)) - 1].__str__()
    body = random.randint(1000000, 9999999).__str__()
    rnd_tel = '7' + operator_code + body
    return rnd_tel
