# -*- coding: utf-8 -*-
import os
import zipfile
from django.core.management import BaseCommand
from dateutil.parser import parse
from datetime import datetime
from django.db import connection
from smsreport.archive.models import Archive
from smsreport.sms.models import Sms
from smsreport.sms.utils import db_table_exists
from smsreport.sql_queries import SELECT_SMS
from psycopg2.extensions import AsIs

from smsreport.templatetags.formatters import pdu_decode
from smsreport.utils import dictfetchall


class Command(BaseCommand):
    help = 'Create archive'

    def add_arguments(self, parser):
        parser.add_argument('date', type=str)
        parser.add_argument(
            '--number_of_group',
            dest='number_of_group',
            default=1000000,
            type=int
        )
        parser.add_argument(
            '--save_path',
            dest='save_path',
            default='',
            type=str
        )

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Start create archive'))
        date = options['date']
        try:
            build_for = parse(date) if date else datetime.now()
        except ValueError:
            return self.stdout.write(self.style.WARNING('Unknown string format for date. Abort.'))

        self.stdout.write(self.style.SUCCESS('Create archive for %s') % (build_for.date(),))
        partition_table = '%s_%s' % (Sms.objects.model._meta.db_table, build_for.strftime('y%Ym%md%d'),)

        if not db_table_exists(partition_table):
            return self.stdout.write(self.style.WARNING('Relation %s is not exists. Abort.' % (partition_table,)))
        offset = 0
        limit = options['number_of_group']
        filenames = []
        rows_count = 0
        is_continue = True
        while is_continue:
            with connection.cursor() as cursor:
                cursor.execute(SELECT_SMS, {
                    'partition_table': AsIs(partition_table),
                    'offset': offset,
                    'limit': limit
                })
                rows = dictfetchall(cursor)
                # decode pdu
                for i, row in enumerate(rows):
                    if row['message'] is not None:
                        rows[i]['message'] = pdu_decode(row['message'])
            if len(rows) > 0:
                filename = os.path.join(options['save_path'], '%s_%07d.csv' % (build_for.date(), offset))
                with open(filename, 'wb') as f:
                    header = ';'.join(['"%s"' % (key, ) for key in rows[0].keys()]) + '\n'
                    body = '\n'.join(
                        [';'.join(['""' if value is None else '"%s"' % (value,) for k, value in row.iteritems()])
                         for row in rows]) + '\n'
                    csv = header + body
                    # write for windows Excel
                    f.write(csv.encode('cp1251', 'ignore'))
                    filenames.append(filename)
                rows_count += len(rows)
                offset += options['number_of_group']
            else:
                is_continue = False
        archive_name = os.path.join(options['save_path'], 'archive_%s.zip' % (build_for.date(), ))
        with zipfile.ZipFile(archive_name, 'w') as z:
            for filename in filenames:
                z.write(filename, os.path.basename(filename), compress_type=zipfile.ZIP_DEFLATED)
            size = sum([info.file_size for info in z.filelist])
            archive_size = float(size) / 1000  # kB
        for filename in filenames:
            if os.path.isfile(filename):
                os.remove(filename)
        archive = Archive(path_to_file=archive_name, description=u'Архив %s' % (build_for.date()),
                          size=archive_size, rows_count=rows_count, type=0)
        archive.save()
        self.stdout.write(self.style.SUCCESS('Finish build archive'))
