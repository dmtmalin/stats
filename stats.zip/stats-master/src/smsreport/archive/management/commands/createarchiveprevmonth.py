from datetime import datetime, timedelta
from django.core.management.base import BaseCommand
from django.core.management import call_command

from smsreport.utils import monthdelta


class Command(BaseCommand):
    help = 'Build archive for previous month'

    def add_arguments(self, parser):
        parser.add_argument(
            '--number_of_group',
            dest='number_of_group',
            default=1000000,
            type=int
        )
        parser.add_argument(
            '--save_path',
            dest='save_path',
            default='',
            type=str
        )

    def handle(self, *args, **options):
        prev_month = monthdelta(datetime.now().date(), -1)
        current = datetime(prev_month.year, prev_month.month, 1)
        finish = monthdelta(current, 1)
        while current < finish:
            call_command(
                'createarchive',
                current.strftime('%Y-%m-%d'),
                number_of_group=options['number_of_group'],
                save_path=options['save_path'])
            current += timedelta(days=1)
