# -*- coding: utf-8 -*-
import os
import csv
import uuid
import zipfile
import time
import random
from django.core.management import BaseCommand
from dateutil.parser import parse
from django.db import connection
from smsreport.archive.models import Archive, GENERATED_DETAILED_TYPE
from smsreport.sms.models import Sms
from smsreport.sms.utils import db_table_exists
from psycopg2.extensions import AsIs
from datetime import datetime, timedelta
from itertools import izip_longest


def gen_iter():
    i = 0
    while True:
        i += 1
        yield i


def rand_dt(start, end, prop):
    stime = time.mktime(start.timetuple()) + start.microsecond / 1E6
    etime = time.mktime(end.timetuple()) + end.microsecond / 1E6
    ptime = stime + prop * (etime - stime)
    return datetime.fromtimestamp(time.mktime(time.localtime(ptime)))


def grouper(n, iterable, fillvalue=None):
    # grouper(3, 'ABCDEFG', 'x') --> ABC DEF Gxx
    args = [iter(iterable)] * n
    return izip_longest(fillvalue=fillvalue, *args)


class Command(BaseCommand):
    help = 'Create archive'

    def add_arguments(self, parser):
        parser.add_argument('date', type=str)
        parser.add_argument(
            '--number_of_group',
            dest='number_of_group',
            default=1000000,
            type=int
        )
        parser.add_argument(
            '--save_path',
            dest='save_path',
            default='',
            type=str
        )
        parser.add_argument(
            '--need',
            dest='need',
            default=0,
            type=int
        )

    def handle(self, *args, **options):
        date = options['date']
        self.stdout.write(self.style.SUCCESS('Start create archive'))
        try:
            build_for = parse(date) if date else datetime.now()
        except ValueError:
            return self.stdout.write(self.style.WARNING('Unknown string format for date. Abort.'))

        self.stdout.write(self.style.SUCCESS('Create archive for %s') % (build_for.date(),))
        partition_table = '%s_%s' % (Sms.objects.model._meta.db_table, build_for.strftime('y%Ym%md%d'),)

        if not db_table_exists(partition_table):
            return self.stdout.write(self.style.WARNING('Relation %s is not exists. Abort.' % (partition_table,)))
        query = """
        SELECT
            routed_cid,
            destination,
            'Out',
            source,
            submit_time :: timestamp without time zone,
            submit_response_time :: timestamp without time zone
        FROM %(partition_table)s;"""
        with connection.cursor() as cursor:
            cursor.execute(query, {'partition_table': AsIs(partition_table), })
            rows = cursor.fetchall()
        g = gen_iter()
        need = options['need']
        if len(rows) == 0:
            return self.stdout.write(self.style.WARNING('Partition is empty. Abort.'))
        if len(rows) < need:
            while len(rows) < need:
                tick = time.time() + time.clock()
                random.seed(tick)
                rand_row = rows[random.randint(0, len(rows) - 1)]
                if rand_row is not None:
                    rand_row = list(rand_row)
                    dt_submit = rand_row[4]
                    dt_now_max = rand_row[4].replace(hour=23, minute=59, second=59, microsecond=999999)
                    dt_new_submit = rand_dt(dt_submit, dt_now_max, random.random())
                    delta = timedelta(microseconds=g.next() + random.randint(1, 5))
                    rand_row[4] = dt_new_submit + delta
                    dt_response_max = dt_new_submit + timedelta(seconds=10, milliseconds=random.randint(1, 1000),
                                                                microseconds=random.randint(1, 1000000))
                    dt_new_response = rand_dt(dt_new_submit, dt_response_max, random.random())
                    rand_row[5] = dt_new_response + delta
                    rows.append(rand_row)
        elif len(rows) > need:
            rows = rows[:need]
        rows.sort(key=lambda r: r[4])
        filenames = []
        header = [u'Оператор', u'MSISDN', u'Тип', u'Маска', u'Дата и время приема/отправки', u'Дата и время доставки абоненту']
        for i in range(len(header)):
            header[i] = header[i].encode('cp1251', 'ignore')
        groups = grouper(options['number_of_group'], rows, fillvalue='')
        for i, g in enumerate(groups):
            filename = os.path.join(options['save_path'], '%s_%07d.csv' % (build_for.date(), i))
            with open(filename, 'wb', zipfile.ZIP_DEFLATED) as f:
                writer = csv.writer(f)
                writer.writerow(header)
                writer.writerows([x for x in g if x])  # избавляемся от пустых элементов
                filenames.append(filename)
        archive_name = os.path.join(options['save_path'], '%s_archive_%s.zip' % (build_for.date(), uuid.uuid4().hex,))
        with zipfile.ZipFile(archive_name, 'w') as z:
            for filename in filenames:
                z.write(filename, os.path.basename(filename), compress_type=zipfile.ZIP_DEFLATED)
            size = sum([info.file_size for info in z.filelist])
            archive_size = float(size) / 1000  # kB
        for filename in filenames:
            if os.path.isfile(filename):
                os.remove(filename)
        archive = Archive(path_to_file=archive_name, description=u'Сгенерированный архив %s' % (build_for.date()),
                          size=archive_size, rows_count=len(rows), type=GENERATED_DETAILED_TYPE)
        archive.save()
        self.stdout.write(self.style.SUCCESS('Finish build archive'))
