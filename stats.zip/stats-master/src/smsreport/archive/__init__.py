default_app_config = 'smsreport.archive.apps.ArchiveConfig'
