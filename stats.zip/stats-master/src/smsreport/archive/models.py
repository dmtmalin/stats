# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

REAL_TYPE = 0
GENERATED_DETAILED_TYPE = 1
GENERATED_EXPANDED_TYPE = 2

ARCHIVE_TYPES = (
    (REAL_TYPE, u'Реальный'),
    (GENERATED_DETAILED_TYPE, u'Сгенерированный детальный'),
    (GENERATED_EXPANDED_TYPE, u'Сгенерированный расширенный'),
)


class Archive(models.Model):
    path_to_file = models.CharField(u'Путь', max_length=255)
    create_at = models.DateTimeField(u'Создан', auto_now_add=True)
    description = models.CharField(u'Описание', max_length=255, null=True, blank=True)
    size = models.IntegerField(u'Размер, Кб')
    rows_count = models.IntegerField(u'Количество записей')
    type = models.IntegerField(u'Тип отчёта', default=0, choices=ARCHIVE_TYPES)

    class Meta:
        verbose_name = u'Архив смс'
        verbose_name_plural = u'Архив смс'

    def __unicode__(self):
        return self.create_at.strftime('%Y-%m-%d %H:%M:%S')
