# -*- coding: utf-8 -*-
import os
import mimetypes
from subprocess import Popen
from django.http.response import StreamingHttpResponse, HttpResponse
from django.views.generic import View
from wsgiref.util import FileWrapper
from smsreport.archive.models import Archive, GENERATED_DETAILED_TYPE, GENERATED_EXPANDED_TYPE
from django.views.generic.edit import FormView
from django.core.urlresolvers import reverse_lazy
from smsreport.archive.forms import CreateDetailedArchiveForm, CreateExpandedArchiveForm
from django.conf import settings
from smsreport.apps import SmsConfig
from django.contrib import messages
from dateutil.parser import parse
from django import forms
from django.contrib.admin.templatetags.admin_static import static
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import user_passes_test
from django.http import Http404
from smsreport.archive.utils import get_generated_detailed_command, get_generated_expanded_command
from smsreport.archive.management.commands.createexpandedarchivedummy import get_description


class ArchiveDownloadView(View):
    def get(self, request, *args, **kwargs):
        archive = Archive.objects.get(id=kwargs['archive_id'])
        filename = archive.path_to_file
        if not os.path.isfile(filename):
            return HttpResponse(content=u'File not exists', status=400)
        chunk_size = 8192
        response = StreamingHttpResponse(FileWrapper(open(filename, 'rb'), chunk_size),
                                         content_type=mimetypes.guess_type(filename)[0])
        response['Content-Length'] = os.path.getsize(filename)
        response['Content-Disposition'] = "attachment; filename=%s" % (os.path.basename(filename), )
        return response

@method_decorator(user_passes_test(lambda u: u.is_superuser, login_url='admin:login'), name='dispatch')
class CreateArchive(FormView):

    success_url = reverse_lazy('admin:index')

    def dispatch(self, request, *args, **kwargs):
        archive_type = self.kwargs.get('type')
        if archive_type == str(GENERATED_DETAILED_TYPE):
            self.template_name = "archive/create_detailed.html"
            self.form_class = CreateDetailedArchiveForm
        elif archive_type == str(GENERATED_EXPANDED_TYPE):
            self.template_name = "archive/create_expanded.html"
            self.form_class = CreateExpandedArchiveForm
        else:
            raise Http404

        return super(CreateArchive, self).dispatch(request, *args, **kwargs)


    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super(CreateArchive, self).get_context_data(**kwargs)

        extra = '' if settings.DEBUG else '.min'
        js = [
            'core.js',
            'vendor/jquery/jquery%s.js' % extra,
            'jquery.init.js',
            'admin/RelatedObjectLookups.js',
            'actions%s.js' % extra,
            'urlify.js',
            'prepopulate%s.js' % extra,
            'vendor/xregexp/xregexp%s.js' % extra,
            'calendar.js',
            'admin/DateTimeShortcuts.js',
        ]
        # Add in a QuerySet of all the books
        context.update({
            'media': forms.Media(js=[static('admin/js/%s' % url) for url in js])
        })
        return context

    def form_valid(self, form):
        description = ''
        archive_type = self.kwargs.get('type')
        if archive_type == str(GENERATED_DETAILED_TYPE):
            cmd_str = get_generated_detailed_command(form.cleaned_data)
            '''data_file = form.cleaned_data.get('file')
            data = data_file.readlines()
            data_file.seek(0)
            count_in_file = form.cleaned_data.get('count_in_file')

            for i in range(len(1, data)):
                line = data[i].rstrip()
                if line == '':
                    break
                if i != 1:
                    cmd_str += '&& '
                line = line.split(',')
                cmd_str += '%s createarchivedummy %s --number_of_group %s --save_path %s --need %s ' \
                           % (SmsConfig.name, parse(line[0]).isoformat(), count_in_file, settings.UPLOAD_PATH, line[1])'''
        elif archive_type == str(GENERATED_EXPANDED_TYPE):
            cmd_str = get_generated_expanded_command(form.cleaned_data)
            '''cmd_str = '%s createexpandedarchivedummy --sms_in_count %s --sms_out_count %s --ussd_in_count %s ' \
                      '--ussd_out_count %s --datetime_start %s --datetime_end %s --save_path %s --count_in_file %s' \
                      % (SmsConfig.name, form.cleaned_data.get('sms_in_count'), form.cleaned_data.get('sms_out_count'),
                         form.cleaned_data.get('ussd_in_count'), form.cleaned_data.get('ussd_out_count'),
                         form.cleaned_data.get('datetime_start').isoformat(), form.cleaned_data.get('datetime_end').isoformat(),
                         settings.UPLOAD_PATH, form.cleaned_data.get('count_in_file'))
            description = u'Описание архива "Сгенерированный расширенный архив %s - %s"' % (form.cleaned_data.get('datetime_start').date(), form.cleaned_data.get('datetime_end').date())'''
            description = get_description(form.cleaned_data.get('datetime_start'), form.cleaned_data.get('datetime_end'))
        Popen(cmd_str, shell=True, stdin=None, stdout=None, stderr=None, close_fds=True)
        messages.add_message(self.request, messages.INFO, u'Задача запущена.' + description)
        return super(CreateArchive, self).form_valid(form)
