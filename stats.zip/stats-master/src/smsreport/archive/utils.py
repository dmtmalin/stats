# -*- coding: utf-8 -*-
from smsreport.apps import SmsConfig
from dateutil.parser import parse
from django.conf import settings


# получить команду для генерации отчёта по дням
def get_generated_detailed_command(cleaned_data):
    cmd_str = ''
    data_file = cleaned_data.get('file')
    data_file.seek(0)
    data = data_file.readlines()
    data_file.seek(0)
    count_in_file = cleaned_data.get('count_in_file')

    for i in range(1, len(data)):
        line = data[i].rstrip()
        if line == '':
            break
        if i != 1:
            cmd_str += '&& '
        line = line.split(',')
        cmd_str += '%s createarchivedummy %s --number_of_group %s --save_path %s --need %s ' \
                   % (SmsConfig.name, parse(line[0]).isoformat(), count_in_file, settings.UPLOAD_PATH, line[1])

    return cmd_str


def get_generated_expanded_command(cleaned_data):
    cmd_str = '%s createexpandedarchivedummy --sms_in_count %s --sms_out_count %s --ussd_in_count %s ' \
              '--ussd_out_count %s --datetime_start %s --datetime_end %s --save_path %s --count_in_file %s' \
              % (SmsConfig.name, cleaned_data.get('sms_in_count'), cleaned_data.get('sms_out_count'),
                 cleaned_data.get('ussd_in_count'), cleaned_data.get('ussd_out_count'),
                 cleaned_data.get('datetime_start').isoformat(), cleaned_data.get('datetime_end').isoformat(),
                 settings.UPLOAD_PATH, cleaned_data.get('count_in_file'))

    return cmd_str
