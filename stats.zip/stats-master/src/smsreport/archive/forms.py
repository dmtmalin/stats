# -*- coding: utf-8 -*-
from django import forms
from dateutil.parser import parse


class CreateDetailedArchiveForm(forms.Form):
    count_in_file = forms.IntegerField(label=u'Количество записей в 1 файле', max_value=1000000)
    file = forms.FileField(label=u'Файл "день/необходимое количество"')

    def clean(self):
        cleaned_data = super(CreateDetailedArchiveForm, self).clean()
        exception = None
        try:
            data_file = cleaned_data.get('file')
            if data_file is None:
                return cleaned_data
            data = data_file.readlines()
            data_file.seek(0)

            for i in range(1, len(data)):
                line = data[i].rstrip()
                if line == '':
                    break
                line = line.split(',')
                if len(line) != 2:
                    exception = forms.ValidationError(
                        u'Невалидный файл. Неверное количество столбцов в строке %s' % (i+1,))
                    break
                if not self.is_dt(line[0]):
                    exception = forms.ValidationError(u'Невалидный файл. Неверный тип даты в строке %s' % (i+1,))
                    break
                if not self.is_int(line[1]):
                    exception = forms.ValidationError(u'Невалидный файл. Неверный числовой тип в строке %s' % (i+1,))
                    break
        except:
            raise forms.ValidationError(u'Невалидный файл')
        if exception is not None:
            raise exception
        return cleaned_data

    @staticmethod
    def is_int(s):
        try:
            int(s)
            return True
        except ValueError:
            return False

    @staticmethod
    def is_dt(s):
        try:
            parse(s)
            return True
        except:
            return False


class CreateExpandedArchiveForm(forms.Form):
    sms_in_count = forms.IntegerField(label=u'Количество входящих SMS', max_value=10000000)
    sms_out_count = forms.IntegerField(label=u'Количество исходящих SMS', max_value=10000000)
    ussd_in_count = forms.IntegerField(label=u'Количество входящих USSD', max_value=10000000)
    ussd_out_count = forms.IntegerField(label=u'Количество исходящих USSD', max_value=10000000)
    datetime_start = forms.DateTimeField(label=u'Начало периода')
    datetime_end = forms.DateTimeField(label=u'Конец периода')
    count_in_file = forms.IntegerField(label=u'Количество записей в 1 файле', max_value=1000000)
