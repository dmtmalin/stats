# -*- coding: utf-8 -*-
from django.conf.urls import url
from django.contrib import admin
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect
from django.utils.html import format_html
from djcelery.admin_utils import action
from django.contrib.admin import helpers

from smsreport.archive.models import Archive
from smsreport.archive.views import ArchiveDownloadView


class ArchiveAdmin(admin.ModelAdmin):

    list_display = ('id', 'type', 'create_at', 'description', 'rows_count', 'size', 'archive_action', )
    ordering = ('-create_at', )
    list_filter = ('type',)
    custom_actions = ['create_detailed_archive', 'create_expanded_archive']
    actions = custom_actions

    @action('Создать сгенерированный отчёт по дням')
    def create_detailed_archive(self, request, queryset):
        return HttpResponseRedirect(reverse('create_archive', kwargs={'type': 1}))

    @action('Создать сгенерированный расширенный отчёт')
    def create_expanded_archive(self, request, queryset):
        return HttpResponseRedirect(reverse('create_archive', kwargs={'type': 2}))

    # отключаем валидацию для наших команд
    def changelist_view(self, request, extra_context=None):
        selected_action = request.POST.get('action')
        if selected_action in self.custom_actions:
            request.POST = request.POST.copy()
            request.POST.setdefault(helpers.ACTION_CHECKBOX_NAME, 0)

        return super(ArchiveAdmin, self).changelist_view(request, extra_context)

    def has_add_permission(self, request):
        return False

    def get_urls(self):
        urls = super(ArchiveAdmin, self).get_urls()
        custom_urls = [
            url(
                r'^(?P<archive_id>.+)/download/$',
                ArchiveDownloadView.as_view(),
                name='archive-download',
            ),
        ]
        return custom_urls + urls

    def archive_action(self, obj):
        return format_html(
            u'<a href="{}">Скачать</a>',
            reverse('admin:archive-download', args=[obj.pk])
        )
    archive_action.short_description = u''
    archive_action.allow_tags = True


admin.site.register(Archive, ArchiveAdmin)
