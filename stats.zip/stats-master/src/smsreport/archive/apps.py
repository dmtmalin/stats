from __future__ import unicode_literals

from django.apps import AppConfig


class ArchiveConfig(AppConfig):
    name = 'smsreport.archive'

    def ready(self):
        import smsreport.archive.signals
