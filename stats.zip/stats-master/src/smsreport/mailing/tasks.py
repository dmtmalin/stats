# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

from celery import shared_task
from django.utils import timezone

from smsreport.mailing.models import Mailing
from smsreport.sms.utils import send_sms


@shared_task
def task_mailing(mailing_id):
    try:
        mailing = Mailing.objects.get(id=mailing_id)
    except Mailing.DoesNotExist:
        return False
    sms_ids = []
    for destination in mailing.destinations:
        sms_id = send_sms(destination, mailing.text, mailing.user, mailing.source)
        sms_ids.append(sms_id)
    mailing.sms_ids = sms_ids
    mailing.send_at = timezone.now()
    mailing.save()
    return True
