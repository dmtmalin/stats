# -*- coding: utf-8 -*-
from datetime import timedelta

from django.utils import timezone
from django.core.management.base import BaseCommand
from django.db.models.expressions import F

from smsreport.mailing.models import Mailing
from smsreport.sms.models import ResendArchive


class Command(BaseCommand):
    help = "To count delivered sms in mailing"

    def add_arguments(self, parser):
        parser.add_argument('previous_day', type=int)

    def handle(self, *args, **options):
        prev_day = options['previous_day']
        dt = timezone.now() - timedelta(days=prev_day)
        self.stdout.write(self.style.SUCCESS('Start to count delivered sms im mailing'))
        mailings = Mailing.objects.filter(
            send_at__isnull=False,
            count_of_sms__gt=F('count_of_delivered'),
            created_at__gte=dt)
        for mailing in mailings:
            count_of_delivered = ResendArchive.objects.filter(
                create_time__gte=mailing.created_at,
                sms_id__in=mailing.sms_ids or []).count()
            mailing.count_of_delivered = count_of_delivered
            mailing.save()
        self.stdout.write(self.style.SUCCESS(
            'Finish to count delivered sms im mailing. Update mailings %s.' % (len(mailings), )))
