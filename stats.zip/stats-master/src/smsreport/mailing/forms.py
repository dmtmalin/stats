# -*- coding: utf-8 -*-
import re
from dateutil.parser import parse
from django import forms
from decimal import Decimal
from django.http import Http404

from smsreport.mailing.models import Mailing
from django.utils.functional import lazy

from smsreport.utils import build_sources_for_mailing, validate_phone_numbers

from constance import config


class CreateMailingForm(forms.ModelForm):
    source = forms.ChoiceField(label=u'Подпись отправления', widget=forms.Select,
                               choices=lazy(build_sources_for_mailing, tuple)())
    text = forms.CharField(label=u'Техт рассылки', widget=forms.Textarea)
    destinations = forms.CharField(label=u'Номера для рассылки (через разделитель)', widget=forms.Textarea)

    # обновление подписи
    def __init__(self, *args, **kwargs):
        super(CreateMailingForm, self).__init__(*args, **kwargs)
        self.fields['source'].choices = lazy(build_sources_for_mailing, tuple)()

    def clean_destinations(self):
        data = self.cleaned_data['destinations']
        return validate_phone_numbers(data)

    def clean_text(self):
        max_length = Mailing._meta.get_field('text').max_length
        data = self.cleaned_data['text']
        if data and len(data) > max_length:
            raise forms.ValidationError(u'Максимальная длина сообщения: %s, текущая %s' % (max_length, len(data), ))
        return data

    def clean(self):
        cleaned_data = super(CreateMailingForm, self).clean()
        count_of_sms = int(cleaned_data.get('count_of_sms', 0))
        if count_of_sms > 0:
            user = cleaned_data.get('user', None)
            if not user or not user.balance:
                raise Http404

            balance_value = Decimal(user.balance.value)
            sms_price = Decimal(config.SMS_PRICE)
            full_cost = sms_price * count_of_sms
            if full_cost > balance_value:
                need_cost = full_cost - balance_value
                raise forms.ValidationError(u'СМС рассылка не возможна, на балансе не хватает %s у.е.'
                                            % ("%.2f" % round(need_cost, 2), ))
        return cleaned_data

    class Meta:
        model = Mailing
        exclude = ('sms_ids', )


class CreateMailingFromFileForm(forms.Form):
    source = forms.ChoiceField(label=u'Подпись отправления', widget=forms.Select,
                               choices=lazy(build_sources_for_mailing, tuple)())
    file = forms.FileField(label=u'Рассылка из файла')

    # обновление подписи
    def __init__(self, *args, **kwargs):
        super(CreateMailingFromFileForm, self).__init__(*args, **kwargs)
        self.fields['source'].choices = lazy(build_sources_for_mailing, tuple)()

    def clean_file(self):
        max_line_counts = 100000
        max_message_length = Mailing._meta.get_field('text').max_length
        max_name_length = Mailing._meta.get_field('name').max_length
        data_file = self.cleaned_data.get('file')
        count_of_sms = 0
        if data_file is None:
            return data_file

        charset = self.get_file_charset(data_file)
        # добавляем формат файла
        self.cleaned_data.update({'charset': charset})

        data = data_file.readlines()
        data_file.seek(0)
        if len(data) > max_line_counts:
            raise forms.ValidationError(u'Невалидный файл. Максимальное количество строк в файле: %s, текущее %s' % (
                max_line_counts, len(data),))
        for i in range(1, len(data)):
            line = data[i].rstrip()
            if line == '':
                break
            line = line.split(',', 3)
            if len(line) != 4:
                raise forms.ValidationError(u'Невалидный файл. Неверное количество столбцов в строке %s' % (i + 1))
            m_name = line[0]
            m_estimated_at = line[1]
            m_tel_numbers = line[2]
            m_message = line[3]
            # проверка имени рассылки
            if not m_name or len(m_name) > max_name_length:
                raise forms.ValidationError(
                    u'Невалидный файл. Максимальная длина имени рассылки в строке %s: %s, текущая %s' % (
                        i + 1, max_name_length, len(m_name),))
            # проверка телефонных номеров
            try:
                validate_phone_numbers(m_tel_numbers)
            except forms.ValidationError as e:
                e.message = u'Невалидный файл. Ошибка в строке %s. ' % (i + 1) + e.message
                raise e
            # проверка текста сообщения
            if m_message and len(m_message) > max_message_length:
                raise forms.ValidationError(
                    u'Невалидный файл. Максимальная длина сообщения в строке %s: %s, текущая %s' % (
                        i + 1, max_message_length, len(m_message),))
            # проверка отложенного времени выполнения
            if m_estimated_at and not self.is_dt(m_estimated_at):
                raise forms.ValidationError(u'Невалидный файл. Неверный тип даты в строке %s' % (i + 1,))

            # обновляем значение количества смс
            count_of_sms += len(re.findall(r"[\w']+", line[2]))

        # проверка, достаточно ли средств на балансе
        if count_of_sms > 0:
            user = self.data.get('user', None)
            if not user or not user.balance:
                raise Http404

            balance_value = Decimal(user.balance.value)
            sms_price = Decimal(config.SMS_PRICE)
            full_cost = sms_price * count_of_sms
            if full_cost > balance_value:
                need_cost = full_cost - balance_value
                raise forms.ValidationError(u'СМС рассылка не возможна, на балансе не хватает %s у.е.'
                                            % ("%.2f" % round(need_cost, 2),))
        else:
            raise forms.ValidationError(u'Невалидный файл. Файл не содержит номеров телефонов.')

        return data_file

    @staticmethod
    def get_file_charset(f):
        charsets = ['utf-8', 'windows-1251']
        correct_charset = ''
        data = f.read()
        f.seek(0)
        for charset in charsets:
            try:
                data.decode(charset)
                correct_charset = charset
                break
            except UnicodeDecodeError:
                pass
        if correct_charset == '':
            raise forms.ValidationError(u'Невалидный файл. Неверная кодировка файла. Необходимые кодировки: '
                                        + ", ".join(['%s']*len(charsets)) % (tuple(charsets)))
        return correct_charset

    @staticmethod
    def is_dt(s):
        try:
            parse(s)
            return True
        except:
            return False
