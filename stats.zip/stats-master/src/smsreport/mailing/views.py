# -*- coding: utf-8 -*-
import re
from decimal import Decimal
from django.conf import settings
from django.core.urlresolvers import reverse_lazy
from django.views.generic.edit import FormView
from django.views.generic.list import ListView
from django.http import Http404
from dateutil.parser import parse
from dateutil.tz import gettz

from smsreport.mailing.forms import CreateMailingForm, CreateMailingFromFileForm
from smsreport.mailing.models import Mailing
from constance import config
from smsreport.mailing.tasks import task_mailing
from smsreport.billing.models import Credit


class MailingList(ListView):
    template_name = "mailing/mailing.html"
    model = Mailing
    ordering = ('-created_at', )

    def get_queryset(self):
        qs = super(MailingList, self).get_queryset()
        return qs.filter(user=self.request.user)

    def get_paginate_by(self, queryset):
        return config.LOST_PAGINATION

    def get_context_data(self, **kwargs):
        context = super(MailingList, self).get_context_data(**kwargs)
        context.update({'celery_tz': settings.CELERY_TIMEZONE})
        user = self.request.user
        if not user or not user.balance:
            raise Http404

        context.update({'user_value': user.balance.value})
        return context


class CreateMailing(FormView):
    template_name = "mailing/create.html"
    form_class = CreateMailingForm
    success_url = reverse_lazy('mailing')

    def form_valid(self, form):
        mailing = form.save()
        task_mailing.apply_async((mailing.id, ), eta=mailing.estimated_at)
        # списываем средства за смс рассылку
        sms_price = Decimal(config.SMS_PRICE)
        full_cost = sms_price * mailing.count_of_sms
        credit = Credit(value=full_cost, user=self.request.user)
        credit.save()

        return super(CreateMailing, self).form_valid(form)

    def get_form_kwargs(self):
        kwargs = super(CreateMailing, self).get_form_kwargs()
        if 'data' in kwargs:
            destinations = kwargs['data'].get('destinations', '')
            count_of_sms = len(re.findall(r"[\w']+", destinations))
            kwargs['data'] = kwargs['data'].copy()
            kwargs['data'].update({
                'count_of_sms': count_of_sms,
                'count_of_delivered': 0,
                'user': self.request.user.id
            })
        return kwargs

    def get_context_data(self, **kwargs):
        context = super(CreateMailing, self).get_context_data(**kwargs)
        context.update({'celery_tz': settings.CELERY_TIMEZONE})
        user = self.request.user
        balance = user.balance.value if user.balance else 0
        context.update({'user_value': balance, 'sms_price': config.SMS_PRICE})
        return context


class CreateMailingFromFile(FormView):
    template_name = "mailing/create_from_file.html"
    form_class = CreateMailingFromFileForm
    success_url = reverse_lazy('mailing')

    def form_valid(self, form):
        sms_price = Decimal(config.SMS_PRICE)
        user = self.request.user
        source = form.cleaned_data.get('source')
        data_file = form.cleaned_data.get('file')
        charset = form.cleaned_data.get('charset')
        data = data_file.readlines()
        data_file.seek(0)
        for i in range(1, len(data)):
            line = data[i].rstrip()
            if not line:
                break
            line = line.split(',', 3)
            name = line[0].decode(charset)
            estimated_at = None
            # парсинг времени выполнения и установка timezone
            if line[1]:
                estimated_at = parse(line[1])
                if not estimated_at.tzinfo:
                    estimated_at = estimated_at.replace(tzinfo=gettz(settings.TIME_ZONE))
            destinations = re.findall(r"[\w']+", line[2].decode(charset))
            text = line[3].decode(charset)

            mailing = Mailing(name=name, user=user, destinations=destinations, text=text, source=source,
                              estimated_at=estimated_at, count_of_sms=len(destinations), count_of_delivered=0)
            mailing.save()
            task_mailing.apply_async((mailing.id, ), eta=mailing.estimated_at)
            full_cost = sms_price * mailing.count_of_sms
            credit = Credit(value=full_cost, user=self.request.user)
            credit.save()

        return super(CreateMailingFromFile, self).form_valid(form)

    def get_form_kwargs(self):
        kwargs = super(CreateMailingFromFile, self).get_form_kwargs()
        if 'data' in kwargs:
            kwargs['data'] = kwargs['data'].copy()
            kwargs['data'].update({
                'user': self.request.user
            })
        return kwargs

    def get_context_data(self, **kwargs):
        context = super(CreateMailingFromFile, self).get_context_data(**kwargs)
        user = self.request.user
        balance = user.balance.value if user.balance else 0
        context.update({'user_value': balance, 'sms_price': config.SMS_PRICE})
        return context
