# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib.postgres.fields.array import ArrayField
from django.db import models

from smsreport.account.models import User


class Mailing(models.Model):
    name = models.CharField(u'Имя рассылки', max_length=255)
    user = models.ForeignKey(User)
    destinations = ArrayField(models.CharField(max_length=15), verbose_name=u'Номера для рассылки')
    sms_ids = ArrayField(models.IntegerField(), null=True, blank=True, verbose_name=u'ID отправленных смс')
    text = models.CharField(u'Техт рассылки', max_length=127)
    created_at = models.DateTimeField(u'Создано', auto_now_add=True, db_index=True)
    send_at = models.DateTimeField(u'Отправлено', blank=True, null=True, db_index=True)
    estimated_at = models.DateTimeField(u'Отложенное время выполнения', blank=True, null=True, db_index=True)
    source = models.CharField(u'Подпись', max_length=15)
    count_of_sms = models.IntegerField(u'Количество смс в рассылки', default=0, db_index=True)
    count_of_delivered = models.IntegerField(u'Количество доставленных смс', default=0, db_index=True)
