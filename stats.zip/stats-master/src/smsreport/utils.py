# -*- coding: utf-8 -*-
import re
import calendar
from django.http.request import QueryDict
from constance import config
from django.db.utils import ProgrammingError
from django import forms


'''
Utils for filtering
'''


def get_paging_filter_data(request, filter_data):
    url = u''
    filter_data = _normalize_filter_data(filter_data)
    if 'page' in request.GET:
        url = request.session.get('filter_data', u'')
    else:
        request.session['filter_data'] = filter_data.urlencode()
    return QueryDict(url)


def get_last_filter_data(request):
    url = request.session.get('filter_data', {})
    return QueryDict(url)


def _normalize_filter_data(filter_data):
    if isinstance(filter_data, QueryDict):
        data = filter_data
    elif isinstance(filter_data, dict):
        query_dict = QueryDict('', mutable=True)
        query_dict.update(filter_data)
        data = query_dict
    else:
        raise ValueError(u"Parameter 'filter_data' must be dict() or QueryDict()")
    return data


'''
Commons utils
'''


# see this page http://www.regular-expressions.info/unicode.html
def remove_non_latin_or_cyrillic_chars(text):
    # is_latin and cyrillic characters
    pattern = ur'[^\u0000-\u007F\u0400-\u04FF]'
    return re.sub(pattern, u'', text)


# https://docs.djangoproject.com/en/1.11/topics/db/sql/
def dictfetchall(cursor):
    # Return all rows from a cursor as a dict
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]


def monthdelta(date, delta):
    m, y = (date.month + delta) % 12, date.year + (date.month + delta-1) // 12
    if not m:
        m = 12
    d = min(date.day, calendar.monthrange(y, m)[1])
    return date.replace(day=d, month=m, year=y)


def list_duplicates(seq):
    seen = set()
    seen_add = seen.add
    # adds all elements it doesn't know yet to seen and all other to seen_twice
    seen_twice = set(x for x in seq if x in seen or seen_add(x))
    # turn the set into a list (as requested)
    return list(seen_twice)

'''
Choice builders
'''


def build_resend_numbers():
    try:
        numbers = re.findall(r"[\w']+", config.RESEND_SMS_NUMBERS)
        return numbers
    except ProgrammingError:
        return tuple()


def build_connector_choices():
    try:
        connectors = re.findall(r"[\w']+", config.CONNECTORS)
        return [(connector, connector.upper()) for connector in connectors]
    except ProgrammingError:
        return tuple()


def build_sources_for_mailing():
    try:
        sources = re.findall(r"[\w']+", config.SOURCES_FOR_MAILING)
        return [(source, source.upper()) for source in sources]
    except ProgrammingError:
        return tuple()


'''
Form validate utils
'''


def validate_phone_numbers(data):
    numbers = re.findall(r"[\w']+", data)
    if not numbers:
        raise forms.ValidationError(u'Номера в тексте %s не найдены' % (data, ))
    duplicates = list_duplicates(numbers)
    if duplicates:
        raise forms.ValidationError(u'Найдены повторяющиеся значения: %s' % (', '.join(duplicates),))
    pattern = re.compile(r"^7\d{10}$")
    for number in numbers:
        if not pattern.match(number):
            raise forms.ValidationError(u'Номер %s должен соответствовать формату 7XXXXXXXXXX' % (number,))
    return numbers
