# -*- coding: utf-8 -*-
import re
from django.contrib.auth.decorators import login_required, user_passes_test
from django.db.models import Sum, Case, When, F
from django.db.models.fields import IntegerField
from django.db.models.query_utils import Q
from django.conf import settings
from datetime import datetime
from django.utils.decorators import method_decorator
from django.views.generic import ListView, View
from django_filters.views import FilterView
from constance import config
from djqscsv.djqscsv import render_to_csv_response
from operator import or_

from smsreport.decorators import login_required_forbidden
from smsreport.report.forms import ReportFilter, ResendArchiveFilter
from smsreport.report.mixins import CurrentDayFilterMixin, RememberFilterSetMixin
from smsreport.report.models import Statistics
from smsreport.sms.models import ResendQueue
from smsreport.utils import get_last_filter_data


def get_user_filter_query(field, s):
    filter_set = re.findall(r"[\w'!~]+", s or '')
    user_filter = []
    for f in filter_set:
        if len(f) > 0 and f[0] == '!':
            user_filter.append(~Q(**{field: f[1:]}))
        elif len(f) > 0 and f[0] == '~':
            user_filter.append(Q(**{'%s__startswith' % (field, ): f[1:]}))
        else:
            user_filter.append(Q(**{field: f}))
    query = Q()
    if len(user_filter) > 0:
        query = reduce(or_, user_filter)
    return query


@method_decorator(login_required(login_url='login_view'), name='dispatch')
class ReportView(CurrentDayFilterMixin, RememberFilterSetMixin, FilterView):
    filterset_class = ReportFilter
    template_name = 'report/report.html'

    def get_context_data(self, **kwargs):
        context = super(ReportView, self).get_context_data(**kwargs)
        statistics = context['statistics_list']
        values = ['source', ]
        section = None
        if 'section' in self.filterset.form.cleaned_data:
            section = self.filterset.form.cleaned_data['section']
            values.extend(section)
        report = statistics.values(*values)
        # filtering by connectors and sources
        user = self.request.user
        if not user.is_staff:
            filter_on_source_connector = get_user_filter_query('source_connector', user.source_connector)
            filter_on_source = get_user_filter_query('source', user.source)
            report = report.filter(filter_on_source_connector | filter_on_source)
        # stat query
        report = report.annotate(
            submit=Sum('count'),
            processing=Sum(
                Case(
                    When(Q(delivery_status__isnull=True) & Q(status=settings.SMS_SUBMIT), then=F('count')),
                    default=0,
                    output_field=IntegerField(),
                )),
            fail_submit=Sum(
                Case(
                    When(~Q(status=settings.SMS_SUBMIT), then=F('count')),
                    default=0,
                    output_field=IntegerField(),
                )),
            fail_delivery=Sum(
                Case(
                    When(~Q(delivery_status=settings.SMS_DELIVERED) & Q(delivery_status__isnull=False) &
                         Q(status=settings.SMS_SUBMIT),
                         then=F('count')),
                    default=0,
                    output_field=IntegerField(),
                )),
            delivery=Sum(
                Case(
                    When(Q(delivery_status=settings.SMS_DELIVERED) & Q(status=settings.SMS_SUBMIT), then=F('count')),
                    default=0,
                    output_field=IntegerField(),
                )),
        )
        report = report.order_by(*section)
        try:
            stat = statistics.latest('update_at')
            last_build = stat.update_at
        except Statistics.DoesNotExist:
            last_build = None
        context.update({
            'report': report,
            'by_operator': 'operator__name' in section,
            'by_connector': 'source_connector' in section,
            'by_date': 'date' in section,
            'last_build': last_build
        })
        return context


@method_decorator(decorator=login_required_forbidden, name='dispatch')
class ReportViewCsv(View):
    filterset_class = ReportFilter

    def get(self, request, *args, **kwargs):
        filter_data = get_last_filter_data(request)
        object_list = self.get_object_list(filter_data)
        return render_to_csv_response(object_list, filename='report_%s' % (datetime.now().date()))

    def get_object_list(self, data):
        filterset = self.filterset_class(data=data)
        return filterset.qs


@method_decorator(user_passes_test(lambda u: u.is_staff, login_url='login_view'), name='dispatch')
class ResendArchiveView(CurrentDayFilterMixin, RememberFilterSetMixin, FilterView):
    filterset_class = ResendArchiveFilter
    template_name = 'report/resend.html'

    def get_paginate_by(self, queryset):
        return config.LOST_PAGINATION


@method_decorator(user_passes_test(lambda u: u.is_staff, login_url='login_view'), name='dispatch')
class ResendQueueView(ListView):
    model = ResendQueue
    template_name = 'report/resend_queue.html'

    def get_paginate_by(self, queryset):
        return config.LOST_PAGINATION
