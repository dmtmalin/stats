# -*- coding: utf-8 -*-
from django.db.models.aggregates import Sum
from django.db.models.expressions import Case, When, F
from django.db.models.query_utils import Q
from django.conf import settings
from django.db.models.fields import IntegerField

from django.core.management.base import BaseCommand
from datetime import datetime
from django.core.cache import cache
from constance import config

from smsreport.account.models import User
from smsreport.report.models import Statistics
from smsreport.utils import build_resend_numbers
from smsreport.sms.utils import send_sms


class Command(BaseCommand):
    help = 'Send warning sms'

    def add_arguments(self, parser):
        parser.add_argument('user', type=str)

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Start send warning sms'))
        stats = self.get_delivery_fails()
        numbers = build_resend_numbers()
        try:
            user = User.objects.get(username=options['user'])
        except User.DoesNotExist:
            return self.stdout.write(self.style.WARNING(u'User %s does not exists. Abort.' % (options['user'])))
        for stat in stats:
            try:
                percent_fail_delivery = float(stat['fail_delivery']) / float(stat['submit']) * 100
            except ZeroDivisionError:
                continue
            if percent_fail_delivery >= config.SMS_ALERT_PERCENT_THRESHOLD\
                    and stat['fail_delivery'] >= config.SMS_ALERT_COUNT_THRESHOLD:
                message = u'%s. Ошибка доставки %s (%0.2f%%), принято %s. %s. %s' % (
                    stat['operator__name'],
                    stat['fail_delivery'],
                    percent_fail_delivery,
                    stat['submit'],
                    stat['source'],
                    datetime.now().date(),
                )
                self.stdout.write(self.style.WARNING(message))
                for destination in numbers:
                    send_messages = cache.get(destination, [])
                    if message in send_messages:
                        continue
                    send_sms(destination, message, user, config.SOURCE_FOR_ALERT)
                    send_messages.append(message)
                    ttl_messages = self.get_ttl_end_day()
                    cache.set(destination, send_messages, ttl_messages)
                    self.stdout.write(self.style.SUCCESS(u'Send to %s' % (destination, )))
        self.stdout.write(self.style.SUCCESS('Finish send warning sms'))

    @staticmethod
    def get_ttl_end_day():
        end = datetime.now().replace(hour=23, minute=59, second=59, microsecond=999999)
        diff = end - datetime.now()
        return int(diff.total_seconds())

    @staticmethod
    def get_delivery_fails():
        now_date = datetime.now().date()
        stats = Statistics.objects.values('source', 'operator__name').filter(date=now_date).annotate(
            submit=Sum('count'),
            fail_delivery=Sum(
                Case(
                    When(~Q(delivery_status=settings.SMS_DELIVERED) & Q(delivery_status__isnull=False)
                         & Q(status=settings.SMS_SUBMIT),
                         then=F('count')),
                    default=0,
                    output_field=IntegerField(),
                )),
        )
        return stats
