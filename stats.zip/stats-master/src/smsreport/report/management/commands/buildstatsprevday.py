# -*- coding: utf-8 -*-
from datetime import datetime, timedelta
from django.core.management.base import BaseCommand
from django.core.management import call_command
from django.utils import timezone
from smsreport.report.models import Statistics
from django.conf import settings


class Command(BaseCommand):
    help = 'Build statistics for previous day'

    def add_arguments(self, parser):
        parser.add_argument('previous_day', type=int)

    def handle(self, *args, **options):
        prev_day = options['previous_day']
        dt = datetime.now().date() - timedelta(days=prev_day)
        call_command('buildstats', date=dt.strftime('%Y-%m-%d'))
        if prev_day >= settings.DELIVERY_RELEASE_DAYS:
            Statistics.objects.filter(
                date=dt, delivery_status__isnull=True, status=settings.SMS_SUBMIT).update(
                delivery_status=settings.SMS_EXPIRED, update_at=timezone.now())
