from datetime import datetime
from dateutil.parser import parse
from django.db import IntegrityError
from django.utils import timezone
from psycopg2.extensions import AsIs
from django.core.management.base import BaseCommand
from django.db import transaction, connection

from smsreport.sms.models import Sms
from smsreport.report.models import Statistics
from smsreport.sms.utils import db_table_exists
from smsreport.sql_queries import AGGREGATE_SMS_FOR_PARTITION
from smsreport.utils import dictfetchall


class Command(BaseCommand):
    help = 'Build statistics for sms'

    def add_arguments(self, parser):
        parser.add_argument(
            '--date',
            dest='date',
            default=None,
            help='Build stats for specific date.',
            type=str
        )

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Start build stats'))
        try:
            Sms.objects.first()
        except Sms.DoesNotExist:
            return self.stdout.write(self.style.WARNING('Sms is empty table. Abort.'))
        date = options['date']
        try:
            build_for = parse(date) if date else datetime.now()
        except ValueError:
            return self.stdout.write(self.style.WARNING('Unknown string format for date. Abort.'))
        self.stdout.write(self.style.SUCCESS('Build stats for %s') % (build_for.date(), ))

        partition_table = '%s_%s' % (Sms.objects.model._meta.db_table, build_for.strftime('y%Ym%md%d'),)

        if not db_table_exists(partition_table):
            return self.stdout.write(self.style.WARNING('Relation %s is not exists. Abort.' % (partition_table, )))

        with connection.cursor() as cursor:
            cursor.execute(AGGREGATE_SMS_FOR_PARTITION, {
                'partition_table': AsIs(partition_table),
            })
            stats = dictfetchall(cursor)
        self.update_statistics(stats, build_for.date())
        self.stdout.write(self.style.SUCCESS('Finish build stats'))

    def update_statistics(self, stats, for_date):
        statistic_list = []
        current_stats = Statistics.objects.filter(date=for_date)
        for s in stats:
            statistic = Statistics(operator_id=s.get('operator_id'), source=s.get('source'),
                                   source_connector=s.get('source_connector'), status=s.get('status'),
                                   date=for_date, delivery_status=s.get('delivery_status'),
                                   count=s.get('count'), update_at=timezone.now())
            statistic_list.append(statistic)
        sid = transaction.savepoint()
        try:
            current_stats.delete()
            Statistics.objects.bulk_create(statistic_list)
            transaction.savepoint_commit(sid)
        except IntegrityError as e:
            transaction.savepoint_rollback(sid)
            return self.stdout.write(self.style.WARNING('Fail create stats. %s.' % (e,)))
        self.stdout.write(self.style.SUCCESS(
            'Finish stats build. Updated: %s' % (len(statistic_list))))
