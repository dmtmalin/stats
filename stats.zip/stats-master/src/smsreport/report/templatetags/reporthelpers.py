# -*- coding: utf-8 -*-
from django import template
from django.db.models import QuerySet

register = template.Library()


@register.filter(name='sum_all')
def sum_all(report):
    if isinstance(report, QuerySet):
        report = list(report)
    report.append({
        'sum_processing': sum_item(report, 'processing'),
        'sum_submit': sum_item(report, 'submit'),
        'sum_delivery': sum_item(report, 'delivery'),
        'sum_fail_submit': sum_item(report, 'fail_submit'),
        'sum_fail_delivery': sum_item(report, 'fail_delivery'),
    })
    return report


@register.filter(name='sum_item')
def sum_item(report, name):
    return sum(item[name] for item in report)
