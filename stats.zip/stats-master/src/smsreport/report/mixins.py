# -*- coding: utf-8 -*-
from datetime import datetime
from datetime import time

from django.conf import settings
from django_filters.views import FilterMixin

from smsreport.utils import get_paging_filter_data


def combine_now_datetime(t):
    combined_datetime = datetime.combine(datetime.now(), t)
    return combined_datetime.strftime(settings.FILTER_DATETIME_FORMAT)


class CurrentDayFilterMixin(FilterMixin):
    def get_filterset_kwargs(self, filterset_class):
        kwargs = super(CurrentDayFilterMixin, self).get_filterset_kwargs(filterset_class)
        if not kwargs['data']:
            kwargs['data'] = {
                'start': combine_now_datetime(time.min),
                'end': combine_now_datetime(time.max)
            }
        return kwargs


class RememberFilterSetMixin(FilterMixin):
    def get_filterset(self, filterset_class):
        kwargs = self.get_filterset_kwargs(filterset_class)
        if kwargs['data']:
            kwargs['data'] = kwargs['data'].copy()
            # if 'page' in request
            paging_filter_data = get_paging_filter_data(
                getattr(self, 'request'),
                kwargs['data']
            )
            kwargs['data'].update(paging_filter_data)
        return filterset_class(**kwargs)
