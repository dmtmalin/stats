# -*- coding: utf-8 -*-
from django import forms
import django_filters as filters

from django.forms.widgets import CheckboxSelectMultiple
from django.utils.functional import lazy

from smsreport.report.models import Statistics
from smsreport.sms.models import Sms, Operator, ResendArchive
from smsreport.utils import build_connector_choices

SECTION_CHOICES = (
    (u'operator__name', u'Оператор'),
    (u'source_connector', u'Коннектор'),
    (u'date', u'День'),
)

DELIVERY_STATUS_CHOICES = (
    (0, u'SCHEDULED (0)'),
    (1, u'ENROUTE (1)'),
    (2, u'DELIVERED (2)'),
    (3, u'EXPIRED (3)'),
    (4, u'DELETED (4)'),
    (5, u'UNDELIVERABLE (5)'),
    (6, u'ACCEPTED (6)'),
    (7, u'UNKNOWN (7)'),
    (8, u'REJECTED (8)'),
    (9, u'SKIPPED (9)'),
)


class ReportFilter(filters.FilterSet):
    section = filters.MultipleChoiceFilter(label=u'Разрез', widget=CheckboxSelectMultiple, choices=SECTION_CHOICES,
                                           method=lambda qs, name, value: qs)
    start = filters.DateTimeFilter(method=lambda qs, name, value: qs.filter(date__gte=value))
    end = filters.DateTimeFilter(method=lambda qs, name, value: qs.filter(date__lte=value))
    operator = filters.ModelMultipleChoiceFilter(
        label=u'Оператор', queryset=Operator.objects.all())
    source = filters.CharFilter(label=u'Подпись')
    source_connector = filters.MultipleChoiceFilter(label=u'Коннектор', choices=lazy(build_connector_choices, tuple)())
    delivery_status = filters.MultipleChoiceFilter(label=u'Статус доставки', choices=DELIVERY_STATUS_CHOICES)
    status = filters.CharFilter(label=u'Статус отправки')

    class Meta:
        model = Statistics
        fields = ['operator', 'source', 'source_connector', 'delivery_status', 'status']


class LostFilter(filters.FilterSet):
    start = filters.DateTimeFilter(method=lambda qs, name, value: qs.filter(create_time__gte=value))
    end = filters.DateTimeFilter(method=lambda qs, name, value: qs.filter(create_time__lte=value))
    operator = filters.ModelMultipleChoiceFilter(
        label=u'Оператор', queryset=Operator.objects.all())
    source = filters.CharFilter(label=u'Подпись')
    source_connector = filters.MultipleChoiceFilter(label=u'Коннектор', choices=lazy(build_connector_choices, tuple)())
    delivery_status = filters.MultipleChoiceFilter(label=u'Статус доставки', choices=DELIVERY_STATUS_CHOICES)
    status = filters.CharFilter(label=u'Статус отправки')

    class Meta:
        model = Sms
        fields = ['operator', 'source', 'source_connector', 'delivery_status', 'status']


class ResendArchiveFilter(filters.FilterSet):
    start = filters.DateTimeFilter(method=lambda qs, name, value: qs.filter(create_time__gte=value))
    end = filters.DateTimeFilter(method=lambda qs, name, value: qs.filter(create_time__lte=value))

    class Meta:
        model = ResendArchive
        fields = ['create_time']


class SendSmsForm(forms.Form):
    sms_id = forms.IntegerField()
