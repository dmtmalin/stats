# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from smsreport.sms.models import Operator


class Statistics(models.Model):
    count = models.IntegerField(u'Количество записей')
    operator = models.ForeignKey(Operator, verbose_name=u'Оператор', db_constraint=False)
    source = models.CharField(u'Подпись', max_length=16, db_index=True)
    source_connector = models.CharField(u'Коннектор', max_length=15, blank=True, null=True, db_index=True)
    status = models.IntegerField(u'Статус', db_index=True)
    delivery_status = models.IntegerField(u'Статус доставки', blank=True, null=True, db_index=True)
    date = models.DateField(u'Дата статистики', db_index=True)
    update_at = models.DateTimeField(u'Время обновления', blank=True, null=True)

    class Meta:
        verbose_name = u'Статистика'
        verbose_name_plural = u'Статистика'
