# -*- coding: utf-8 -*-
from django.contrib import admin

from smsreport.sms.models import Operator


class OperatorAdmin(admin.ModelAdmin):
    add_fieldsets = (
        (None, {'fields': ('id', 'routed_cid', 'name',)}),
    )
    list_display = ('id', 'routed_cid', 'name',)

admin.site.register(Operator, OperatorAdmin)
