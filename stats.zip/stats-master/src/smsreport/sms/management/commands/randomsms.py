from datetime import datetime, timedelta
from random import randint, choice
from django.core.management.base import BaseCommand
from django.utils import timezone

from smsreport.sms.models import Operator, Sms


class Command(BaseCommand):
    help = 'WARNING! Generate random sms data'

    def add_arguments(self, parser):
        parser.add_argument('count', type=int)
        parser.add_argument('numdays', type=int)

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Start generate random sms data.'))

        one_percent = float(options['count'])/100.0
        operators = Operator.objects.values_list('id', flat=True)
        delivery_status = [None, ]
        delivery_status += range(0, 10)

        sms_list = []
        now = datetime.now()
        tz = timezone.get_current_timezone()
        for i in range(0, options['count']):
            dt = datetime(now.year, now.month, now.day, randint(0, 23), randint(0, 59), randint(0, 59), tzinfo=tz)
            dt = dt + timedelta(days=randint(0, options['numdays']))

            sms = Sms(
                message_id="test_%s" % (i, ),
                remote_message_id="test_remote_%s" % (i, ),
                routed_cid="routed_cid_%s" % (randint(0, 9), ),
                source='source_%s' % (randint(0, 9),),
                source_connector='source_conn_%s' % (randint(0, 4),),
                status=randint(0, 9),
                create_time=dt,
                submit_time=dt,
                operator_id=choice(operators),
                delivery_status=choice(delivery_status),
                send_attempt=0)
            sms_list.append(sms)

            if i % one_percent == 0 and i > 0:
                Sms.objects.bulk_create(sms_list)
                self.stdout.write(self.style.SUCCESS('Generated %s sms objects, next.' % (len(sms_list),)))
                del sms_list[:]
        if len(sms_list) > 0:
            Sms.objects.bulk_create(sms_list)
            self.stdout.write(self.style.SUCCESS('Generated %s sms objects, finish.' % (len(sms_list),)))
