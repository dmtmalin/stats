from psycopg2.extensions import AsIs
from datetime import datetime, timedelta, time
from django.core.management.base import BaseCommand
from django.db import connection

from smsreport.sms.models import Sms
from smsreport.sms.utils import db_table_exists
from smsreport.sql_queries import CREATE_PARTITION_SQL


class Command(BaseCommand):
    help = 'Create partition for number days'

    def add_arguments(self, parser):
        parser.add_argument('numdays', type=int)

    def handle(self, *args, **options):
        dates = [datetime.now().date() + timedelta(days=n) for n in range(0, options['numdays'])]
        master_table = get_master_table()
        for date in dates:
            partition_table = get_partition_table(master_table, date)

            if not db_table_exists(partition_table):
                with connection.cursor() as cursor:
                    cursor.execute(CREATE_PARTITION_SQL, {
                        'master_table': AsIs(master_table),
                        'partition_table': AsIs(partition_table),
                        'check_from': datetime.combine(date, time.min),
                        'check_to': datetime.combine(date, time.max)
                    })
                self.stdout.write(self.style.SUCCESS('Created table %s' % (partition_table, )))
        self.stdout.write(self.style.SUCCESS('Finish create partition'))


def get_master_table():
    return Sms.objects.model._meta.db_table


def get_partition_table(master_table, date):
    return '%s_%s' % (master_table, date.strftime('y%Ym%md%d'),)

