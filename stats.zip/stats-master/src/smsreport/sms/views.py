# -*- coding: utf-8 -*-
from django.contrib.auth.decorators import login_required, user_passes_test
from django.conf import settings
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import FormView
from django.views.generic import View
from django_filters.views import FilterView

from smsreport.decorators import login_required_forbidden
from smsreport.report.forms import SendSmsForm, LostFilter
from smsreport.report.mixins import CurrentDayFilterMixin, RememberFilterSetMixin
from smsreport.sms.forms import SmsFilter
from smsreport.sms.models import Sms, ResendQueue
from smsreport.sms.utils import convert_sms_to_resend_queue, build_response_message
from smsreport.utils import get_last_filter_data
from constance import config

from django.db import IntegrityError, transaction


@method_decorator(login_required(login_url='login_view'), name='dispatch')
class ResendSmsAction(FormView):
    form_class = SendSmsForm

    def form_valid(self, form):
        sms_id_list = self.request.POST.getlist('sms_id')
        last_filter_data = get_last_filter_data(self.request)
        sms_list = Sms.objects.filter(
            pk__in=sms_id_list,
            create_time__gte=last_filter_data.get('start'),
            create_time__lte=last_filter_data.get('end'))
        resend_queue = [convert_sms_to_resend_queue(self.request, sms) for sms in sms_list]
        sid = transaction.savepoint()
        try:
            ResendQueue.objects.bulk_create(resend_queue)
            sms_list.delete()
            transaction.savepoint_commit(sid)
        except IntegrityError as e:
            transaction.savepoint_rollback(sid)
            return JsonResponse({
                'message': e.message,
                'sms_sends': 0,
            })
        message = build_response_message(len(resend_queue), last_filter_data)
        return JsonResponse({
            'message': message,
            'sms_sends': [q.sms_id for q in resend_queue],
        })

    def form_invalid(self, form):
        return JsonResponse({
            'message': u'Укажите хотя бы один объект для отправки',
        })


@method_decorator([csrf_exempt, login_required_forbidden], name='dispatch')
class MassResendSmsAction(View):
    filterset_class = LostFilter

    def post(self, request, *args, **kwargs):
        filter_data = get_last_filter_data(request)
        object_list = self.get_object_list(filter_data)
        resend_queue = [convert_sms_to_resend_queue(request, sms) for sms in object_list]
        sid = transaction.savepoint()
        try:
            ResendQueue.objects.bulk_create(resend_queue)
            object_list.delete()
            transaction.savepoint_commit(sid)
        except IntegrityError as e:
            transaction.savepoint_rollback(sid)
            return JsonResponse({
                'message': e.message,
            })
        message = build_response_message(len(resend_queue), filter_data)
        return JsonResponse({
            'message': message,
        })

    def get_object_list(self, data):
        filterset = self.filterset_class(data=data)
        return filterset.qs


class SmsFilterView(FilterView):
    def get(self, request, *args, **kwargs):
        filterset_class = self.get_filterset_class()
        self.filterset = self.get_filterset(filterset_class)
        self.object_list = self.filterset.qs if request.GET else Sms.objects.none()
        context = self.get_context_data(filter=self.filterset,
                                        object_list=self.object_list)
        return self.render_to_response(context)


@method_decorator(login_required(login_url='login_view'), name='dispatch')
class SmsView(CurrentDayFilterMixin, RememberFilterSetMixin, SmsFilterView):
    filterset_class = SmsFilter
    template_name = 'sms/sms.html'

    def get_paginator(self, queryset, per_page, orphans=0, allow_empty_first_page=True, **kwargs):
        limit = config.SMS_ROWS_LIMIT
        queryset = queryset[:limit]
        return super(SmsView, self).get_paginator(queryset, per_page, orphans, allow_empty_first_page, **kwargs)

    def get_paginate_by(self, queryset):
        return config.LOST_PAGINATION


@method_decorator(user_passes_test(lambda u: u.is_staff, login_url='login_view'), name='dispatch')
class LostView(CurrentDayFilterMixin, RememberFilterSetMixin, SmsFilterView):
    filterset_class = LostFilter
    template_name = 'sms/lost.html'

    def get_context_data(self, **kwargs):
        kwargs['object_list'] = kwargs['object_list'].filter(delivery_status__isnull=False).exclude(
            status=settings.SMS_SUBMIT, delivery_status=settings.SMS_DELIVERED)
        context = super(LostView, self).get_context_data(**kwargs)
        return context

    def get_paginator(self, queryset, per_page, orphans=0, allow_empty_first_page=True, **kwargs):
        limit = config.SMS_ROWS_LIMIT
        queryset = queryset[:limit]
        return super(LostView, self).get_paginator(queryset, per_page, orphans, allow_empty_first_page, **kwargs)

    def get_paginate_by(self, queryset):
        return config.LOST_PAGINATION
