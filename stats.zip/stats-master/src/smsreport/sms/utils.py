# -*- coding: utf-8 -*-
import uuid
from django.core.cache import cache
from django.db import connection

from smsreport.sql_queries import SELECT_TABLE_NAME
from smpp.pdu.pdu_types import AddrTon, AddrNpi, EsmClass, EsmClassMode, EsmClassType, EsmClassGsmFeatures, \
    PriorityFlag, RegisteredDelivery, RegisteredDeliveryReceipt, ReplaceIfPresentFlag, DataCoding, DataCodingScheme, \
    DataCodingDefault
from smpp.pdu.operations import SubmitSM
from smpp.pdu.pdu_encoding import PDUEncoder
from smsreport.sms.models import ResendQueue
from smsreport.sql_queries import SELECT_NEXT_ID


def convert_sms_to_resend_queue(request, sms):
    queue = ResendQueue(
        sms_id=sms.id,
        message_id=sms.message_id,
        message=sms.message,
        source_connector=sms.source_connector,
        send_attempt=sms.send_attempt,
        user=request.user
    )
    return queue


def build_response_message(sms_len, filter_data):
    message = list()
    message.append(u'Отправлено сообщений %s\n' % (sms_len, ))
    message.append(u'Фильтр отправки:\n')
    filter_list = [u'\t%s: %s\n' % (key, filter_data[key],) for key in filter_data]
    message.append(u''.join(filter_list))
    return u''.join(message)


def db_table_exists(table):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_TABLE_NAME, {'table_name': table})
        table_name = cursor.fetchone()
        return True if table_name else False


def get_new_sms_id():
    with connection.cursor() as cursor:
        cursor.execute(SELECT_NEXT_ID, {
            'table': 'sms_sms',
        })
        result = cursor.fetchone()
        return result[0]


def send_sms(destination, short_message, user, source):
    sequence_ttl = 86400
    sequence_number = cache.get_or_set('sequence', 1, sequence_ttl)
    if sequence_number >= 32767:
        cache.set('sequence', 1, sequence_ttl)
        sequence_number = 1
    sms_id = get_new_sms_id()
    pdu = SubmitSM(
        sequence_number,
        service_type='',
        source_addr_ton=AddrTon.ALPHANUMERIC,
        source_addr_npi=AddrNpi.UNKNOWN,
        source_addr=source,
        dest_addr_ton=AddrTon.INTERNATIONAL,
        dest_addr_npi=AddrNpi.ISDN,
        destination_addr=destination,
        esm_class=EsmClass(EsmClassMode.DEFAULT, EsmClassType.DEFAULT),  # [EsmClassGsmFeatures.UDHI_INDICATOR_SET]
        protocol_id=0,
        priority_flag=PriorityFlag.LEVEL_0,
        registered_delivery=RegisteredDelivery(
            RegisteredDeliveryReceipt.SMSC_DELIVERY_RECEIPT_REQUESTED),
        replace_if_present_flag=ReplaceIfPresentFlag.DO_NOT_REPLACE,
        data_coding=DataCoding(DataCodingScheme.DEFAULT,
                               DataCodingDefault.UCS2),
        short_message=short_message.encode('utf-16be'),
    )
    binary = PDUEncoder().encode(pdu)
    queue = ResendQueue(sms_id=sms_id, message_id=uuid.uuid4().hex, message=binary, source_connector=source,
                        send_attempt=0, user=user)
    queue.save()
    cache.incr('sequence')
    return sms_id
