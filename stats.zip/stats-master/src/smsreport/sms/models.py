# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from smsreport.account.models import User
from smsreport.models import BigIntegerAutoField


class Operator(models.Model):
    id = models.IntegerField(u'Идентификатор', primary_key=True)
    routed_cid = models.CharField(u'CID', max_length=50, db_index=True, blank=True, null=True)
    name = models.CharField(u'Имя', max_length=50)

    class Meta:
        verbose_name = u'Оператор'
        verbose_name_plural = u'Операторы'
        ordering = ('name', )

    def __unicode__(self):
        return self.name


# Master table no indexes, partitioning by create_time, use command 'createpartition <numdays>' for create partition
class Sms(models.Model):
    id = BigIntegerAutoField(primary_key=True)
    message_id = models.CharField(u'ID сообщения', max_length=45)
    remote_message_id = models.CharField(u'Внешний ID сообщения', max_length=45)
    message = models.BinaryField(u'Сообщение', blank=True, null=True)
    source_connector = models.CharField(u'Коннектор', max_length=15, blank=True, null=True)
    routed_cid = models.CharField(u'CID', max_length=15)
    destination = models.CharField(u'Получатель', max_length=40, blank=True, null=True)
    source = models.CharField(u'Подпись', max_length=16)
    pdu_count = models.IntegerField(u'Количество PDU', default=1)
    status = models.IntegerField(u'Статус')
    create_time = models.DateTimeField(u'Создано')
    submit_time = models.DateTimeField(u'Отправлено')
    submit_response_time = models.DateTimeField(u'Обработано', blank=True, null=True)
    delivery_report_time = models.DateTimeField(u'Отчет о доставке', blank=True, null=True)
    delivery_time = models.DateTimeField(u'Доставлено', blank=True, null=True)
    delivery_status = models.IntegerField(u'Статус доставки', blank=True, null=True)
    delivery_err = models.IntegerField(u'Ошибка доставки', blank=True, null=True)
    operator = models.ForeignKey(Operator, verbose_name=u'Оператор', db_constraint=False, db_index=False)
    send_attempt = models.IntegerField(u'Попыток отправки')

    class Meta:
        verbose_name = u'SMS'
        verbose_name_plural = u'SMS'

    def __unicode__(self):
        return self.message_id


class ResendAbstract(models.Model):
    create_time = models.DateTimeField(u'Создано', auto_now_add=True, db_index=True)
    sms_id = models.IntegerField(u'ID sms')
    message_id = models.CharField(u'ID сообщения', max_length=45)
    message = models.BinaryField(u'Сообщение', blank=True, null=True)
    source_connector = models.CharField(u'Коннектор', max_length=15, blank=True, null=True)
    send_attempt = models.IntegerField(u'Попыток отправки')
    reason = models.CharField(u'Причина', max_length=50, blank=True, null=True)
    user = models.ForeignKey(User)

    class Meta:
        abstract = True

    def __unicode__(self):
        return self.message_id


class ResendQueue(ResendAbstract):
    class Meta:
        db_table = 'sms_resend_q'
        ordering = ('-create_time',)
        verbose_name = u'Очередь на переотправку'
        verbose_name_plural = u'Очередь на переотправку'


class ResendArchive(ResendAbstract):
    processed_time = models.DateTimeField(u'Время обработки', db_index=True)

    class Meta:
        db_table = 'sms_resend_arc'
        ordering = ('-create_time',)
        verbose_name = u'Переотправленные sms'
        verbose_name_plural = u'Переотправленные sms'
