# -*- coding: utf-8 -*-
import django_filters as filters
from django.utils.functional import lazy

from smsreport.report.forms import DELIVERY_STATUS_CHOICES
from smsreport.sms.models import Sms
from smsreport.utils import build_connector_choices


class SmsFilter(filters.FilterSet):
    start = filters.DateTimeFilter(method=lambda qs, name, value: qs.filter(create_time__gte=value))
    end = filters.DateTimeFilter(method=lambda qs, name, value: qs.filter(create_time__lte=value))
    message_id = filters.CharFilter(label=u'ID сообщения', method='filter_message_id')
    destination = filters.CharFilter(label=u'Получатель')
    source = filters.CharFilter(label=u'Подпись')
    source_connector = filters.MultipleChoiceFilter(label=u'Коннектор', choices=lazy(build_connector_choices, tuple)())
    delivery_status = filters.MultipleChoiceFilter(label=u'Статус доставки', choices=DELIVERY_STATUS_CHOICES)
    status = filters.CharFilter(label=u'Статус отправки')

    def filter_message_id(self, qs, name, value):
        clean_value = value.replace('-', '')
        return qs.filter(**{name: clean_value})

    class Meta:
        model = Sms
        fields = ['message_id', 'destination', 'source', 'source_connector', 'delivery_status', 'status']
