# -*- coding: utf-8 -*-
import os

DEBUG = os.environ.get('DEBUG')

ALLOWED_HOSTS = ['*']

# Timezone
TIME_ZONE = 'Europe/Moscow'

# База данных
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'HOST': os.environ.get('POSTGRES_HOST') or 'localhost',
        'PORT': os.environ.get('POSTGRES_PORT') or '5432',
        'NAME': os.environ.get('STATS_DATABASE_NAME') or 'sms',
        'USER': os.environ.get('POSTGRES_USER') or 'postgres',
        'PASSWORD': os.environ.get('POSTGRES_PASS') or 'root',
    }
}

# Брокер
BROKER_URL = os.environ.get('BROKER_URL')
BROKER_TRANSPORT_OPTIONS = {
    'sentinels': [('nuanced-magpie-redis-ha-announce-0.sms', 26379),
                  ('nuanced-magpie-redis-ha-announce-1.sms', 26379),
                  ('nuanced-magpie-redis-ha-announce-2.sms', 26379)],
    'service_name': 'smsmaster',
    'socket_timeout': 0.1,
}

CELERY_RESULT_BACKEND = os.environ.get('CELERY_RESULT_BACKEND')
CELERY_RESULT_BACKEND_TRANSPORT_OPTIONS = BROKER_TRANSPORT_OPTIONS
# Celery timezone
CELERY_TIMEZONE = 'Europe/Moscow'

# Путь по которому раздаётся статика приложения
STATIC_ROOT = os.environ.get('STATIC_PATH')

# Кэш
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
        'LOCATION': os.environ.get('MEMCACHE'),
    }
}

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler'
        },
    },
    'loggers': {
        '': {  # 'catch all' loggers by referencing it with the empty string
            'handlers': ['console'],
            'level': os.getenv('DJANGO_LOG_LEVEL', 'INFO'),
        },
    },
}
