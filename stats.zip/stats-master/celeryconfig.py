import os

# Брокер
BROKER_URL = os.environ.get('BROKER_URL')
BROKER_TRANSPORT_OPTIONS = {
    'sentinels': [('nuanced-magpie-redis-ha-announce-0.sms', 26379),
                  ('nuanced-magpie-redis-ha-announce-1.sms', 26379),
                  ('nuanced-magpie-redis-ha-announce-2.sms', 26379)],
    'service_name': 'smsmaster',
    'socket_timeout': 0.1,
}

CELERY_RESULT_BACKEND = os.environ.get('CELERY_RESULT_BACKEND')
CELERY_RESULT_BACKEND_TRANSPORT_OPTIONS = BROKER_TRANSPORT_OPTIONS
# Celery timezone
CELERY_TIMEZONE = 'Europe/Moscow'
CELERY_APP: smsreport
CELERYD_CHDIR: '/opt/smsreport'